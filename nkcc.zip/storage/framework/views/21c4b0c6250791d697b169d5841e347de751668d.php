<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://unpkg.com/@themesberg/flowbite@1.2.0/dist/flowbite.min.css" />
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->

 

    <!-- ===== Header End ===== -->

    <main>
        <section class=" bg-[url('/images/contact1.jpg')]  lg:bg-cover mt-16 ">
            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class="  lg:ml-6 mx-4 mt-24 lg:mt-52 lg:mr-6 lg:px-20 h-96">
                    <h1 class="text-5xl font-serif text-left ml-9 mt-44 text-white bg-black px-4">
                        Contactez-nous
                    </h1>
                    <div class="ml-9  mt-4">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>


                </div>

            </div>

        </section>
        <section class="bg-gray-200  justify-start">
            <div class="h-12">
            </div>
            <div class="">
                <h2 class=" text-black text-xl lg:text-3xl lg:mx-24 ">Vous êtes...
                </h2>
                <div class="lg:mx-24 mx-6">

                    <div class="border-b border-gray-200 dark:border-gray-700 mb-4 mt-9">
                        <ul class="lg:flex " id="myTab" data-tabs-toggle="#myTabContent" role="tablist">
                            <li class="lg:mr-2 lg:w-1/4 " role="presentation">

                                <button
                                    class="whitespace-nowrap   inline-block text-black hover:text-gray-600 hover:border-gray-300 rounded-t-lg py-4 px-4 text-lg  text-center border-transparent border-b-2 "
                                    id="profile-tab" data-tabs-target="#profile" type="button" role="tab"
                                    aria-controls="profile" aria-selected="false"><img
                                        src="images/DAMIL_123742-132-orange.svg"
                                        alt="marketing-digital-service-création-de-site-web" id="profile-tab"
                                        data-tabs-target="#profile" class=""> Une entreprise</button>
                            </li>
                            <li class="lg:mr-2 lg:w-1/4 " role="presentation">

                                <button
                                    class="whitespace-nowrap  inline-block text-black hover:text-gray-600 hover:border-gray-300 rounded-t-lg py-4 px-4 text-lg text-center border-transparent border-b-2  active"
                                    id="dashboard-tab" data-tabs-target="#dashboard" type="button" role="tab"
                                    aria-controls="dashboard" aria-selected="true"> <img
                                        src="images/picto-news-report-orange.svg"
                                        alt="marketing-digital-service-création-de-site-web" id="dashboard-tab"
                                        data-tabs-target="#dashboard" class="">Un média</button>
                            </li>
                            <li class="lg:mr-2 lg:w-1/4 " role="presentation">

                                <button
                                    class="whitespace-nowrap  inline-block text-black hover:text-gray-600 hover:border-gray-300 rounded-t-lg py-4 px-4 text-lg  border-transparent border-b-2 "
                                    id="settings-tab" data-tabs-target="#settings" type="button" role="tab"
                                    aria-controls="settings" aria-selected="false"> <img
                                        src="images/DAMIL_123752-132-orange.svg"
                                        alt="marketing-digital-service-création-de-site-web" id="settings-tab"
                                        data-tabs-target="#settings" class="lg:ml-16"> En recherche
                                    d'emploi/stage</button>
                            </li>
                            <li class="lg:w-1/4 " role="presentation">

                                <button
                                    class="whitespace-nowrap   text-black hover:text-gray-600 hover:border-gray-300 rounded-t-lg py-4 px-4 text-lg text-center border-transparent border-b-2 "
                                    id="contacts-tab" data-tabs-target="#contacts" type="button" role="tab"
                                    aria-controls="contacts" aria-selected="false"> <img
                                        src="images/DAMIL_123766-132-orange.svg"
                                        alt="marketing-digital-service-création-de-site-web" id="contacts-tab"
                                        data-tabs-target="#contacts" class="lg:ml-20"> Une école / Une association
                                    étudiante</button>
                            </li>
                        </ul>
                    </div>
                    <div id="myTabContent">
                        <div class=" p-4 rounded-lg  lg:h-80 hidden" id="profile" role="tabpanel"
                            aria-labelledby="profile-tab">
                            <div class="lg:flex ">
                                <img src="images/fond7.jpg" alt="marketing-digital-service-création-de-site-web"
                                    class="h-44 w-80">
                                <div class="">
                                    <p class=" text-sm text-center lg:text-lg lg:ml-9  mt-4 text-gray-600">
                                        Vous représentez une entreprise / organisation et souhaitez nous soumettre une
                                        demande ou un besoin ?
                                    </p>
                                    <a href="/#"
                                        class="flex  gi lg:mt-9 mt-6 lg:ml-9 w-44 text-black border border-black hover:bg-blue-700 block">
                                        <span class="ml-9">Contactez-nous</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </a>
                                    <a href="/#"
                                        class="flex bg-orange-700  gi lg:mt-24 mt-6 lg:ml-9 w-64 text-black border border-black hover:bg-blue-700 block">
                                        <span class="ml-9">Pour toute autre demande</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="lg:h-80 p-4 rounded-lg " id="dashboard" role="tabpanel"
                            aria-labelledby="dashboard-tab">
                            <div class="lg:flex ">
                                <img src="images/WhatsApp Image 2023-07-18 at 18.11.34.jpeg"
                                    alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">
                                <div class="flrx">
                                    <p class=" text-sm text-center lg:text-lg lg:ml-9  mt-4 text-gray-600">
                                        Vous voulez contacter le service des relations presse de NKCCG France et Maghreb
                                        ?
                                    </p>
                                    <a href="/#"
                                        class="flex mt-6 gi lg:mt-9 lg:ml-9 w-44 text-black border border-black hover:bg-blue-700 block">
                                        <span class="ml-9">Contactez-nous</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </a>
                                    <a href="/#"
                                        class="flex bg-orange-700 my-6 gi lg:mt-24 lg:ml-9 w-64 text-black border border-black hover:bg-blue-700 block">
                                        <span class="ml-9">Pour toute autre demande</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="lg:h-80 p-4 rounded-lg  hidden" id="settings" role="tabpanel"
                            aria-labelledby="settings-tab">
                            <div class="lg:flex ">
                                <img src="images/groupe-afro.webp"
                                    alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">
                                <div class="flrx">
                                    <p class=" text-sm text-center lg:text-lg lg:ml-9  mt-4 text-gray-600">
                                        Vous recherchez une opportunité professionnelle ou avez une question sur les
                                        offres d'emploi ou les stages au sein de NKCCG France et Maghreb ?
                                    </p>
                                    <a href="/#"
                                        class="flex mt-6 gi lg:mt-9 lg:ml-9 w-44 text-black border border-black hover:bg-blue-700 block">
                                        <span class="ml-9">Contactez-nous</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </a>
                                    <a href="/#"
                                        class="flex mt-6 bg-orange-700  gi lg:mt-24 lg:ml-9 w-64 text-black border border-black hover:bg-blue-700 block">
                                        <span class="ml-9">Pour toute autre demande</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="lg:h-80 p-4 rounded-lg  hidden" id="contacts" role="tabpanel"
                            aria-labelledby="contacts-tab">
                            <div class="lg:flex ">
                                <img src="images/photo-1661956602153-23384936a1d3.webp"
                                    alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">
                                <div class="flrx">
                                    <p class=" text-sm text-center lg:text-lg lg:ml-9  mt-4 text-gray-600">
                                        Vous êtes membre d'une école de commerce, d'ingénieur, d'université et d'une
                                        association étudiante ?
                                    </p>
                                    <a href="/#"
                                        class="flex mt-6 gi lg:mt-9 lg:ml-9 w-44 text-black border border-black hover:bg-blue-700 block">
                                        <span class="ml-9">Contactez-nous</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </a>
                                    <a href="/#"
                                        class="flex mt-6 bg-orange-700  gi lg:mt-24 lg:ml-9 w-64 text-black border border-black hover:bg-blue-700 block">
                                        <span class="ml-9">Pour toute autre demande</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </section>
        <section class="">
            <div class="lg:mx-32 mx-6">
                <h1 class="lg:text-4xl  text-2xl font-serif text-left  mt-9 text-black">
                    Rechercher un contact par métiers, enjeux ou secteurs d'activité
                </h1>
                <div class="mb-6">
                    <select id="countries"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-lg  focus:ring-blue-500 focus:border-blue-500 block lg:w-1/4 mt-4 p-2.5 "
                        required>
                        <option selected>
                            All Specialties
                        </option>
                        <option value="za">Afrique du Sud</option>
                        <option value="al">Albanie</option>
                        <option value="dz">Algérie</option>
                        <option value="de">Allemagne</option>
                        <option value="xa">Amérique centrale</option>
                        <option value="ad">Andorra</option>
                        <option value="ao">Angola</option>
                        <option value="ag">Antigua</option>
                        <option value="an">Antilles néerlandaises</option>
                        <option value="sa">Arabie Saoudite</option>
                        <option value="ar">Argentine</option>
                        <option value="am">Arménie</option>
                        <option value="aw">Aruba</option>
                        <option value="w1">Asia Pacific Customs and Trade</option>
                        <option value="cs">Asie centrale et Caucase</option>
                        <option value="au">Australie</option>
                        <option value="at">Autriche</option>
                        <option value="az">Azerbaïdjan</option>
                        <option value="bs">Bahamas
                        </option>
                        <option value="bh">Bahreïn
                        </option>
                        <option value="bd">Bangladesh</option>
                        <option value="bb">Barbade</option>

                    </select>
                </div>
                <div class="lg:flex">
                    <div class="flex  mt-6">
                        <div class="flex ">
                            <img src="images/fr-france-800xage.jpg"
                                alt="marketing-digital-service-création-de-site-web" class=" ">
                        </div>
                        <div class=" ">
                            <h1 class="lg:text-2xl text-lg mx-6 font-serif text-black">Jean-François Marti</h1>
                            <p class="mx-6 text-sm  mt-2 text-gray-600">
                                Associé, Transformation par l'humain,<br> NKCCG France et Maghreb
                            </p>
                            <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                        </div>

                    </div>
                    <div class="flex  mt-6">
                        <div class="flex ">
                            <img src="images/fr-france-800xage.jpg"
                                alt="marketing-digital-service-création-de-site-web" class=" ">
                        </div>
                        <div class=" ">
                            <h1 class="lg:text-2xl text-lg mx-6 font-serif text-black">Jean-François Marti</h1>
                            <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                                Associé, Transformation par l'humain,<br> NKCCG France et Maghreb
                            </p>
                            <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                        </div>

                    </div>
                    <div class="flex  mt-6">
                        <div class="flex ">
                            <img src="images/fr-france-800xage.jpg"
                                alt="marketing-digital-service-création-de-site-web" class=" ">
                        </div>
                        <div class=" ">
                            <h1 class="lg:text-2xl text-lg mx-6 font-serif text-black">Jean-François Marti</h1>
                            <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                                Associé, Transformation par l'humain,<br> NKCCG France et Maghreb
                            </p>
                            <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                        </div>

                    </div>
                </div>
                
            </div>

        </section>
        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>
    
                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>
    
    
                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>
    
                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires
    
                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>
    
                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact
    
                            </a>
                        </li>
    
                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>
    
        </div>
        </div>
    
    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>
<script src="https://unpkg.com/@themesberg/flowbite@1.2.0/dist/flowbite.bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/contactez.blade.php ENDPATH**/ ?>