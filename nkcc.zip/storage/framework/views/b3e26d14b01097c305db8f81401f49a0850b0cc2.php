<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->

 
    <!-- ===== Header End ===== -->

    <main>

        <section class=" bg-[url('/images/blog-1.jpg')]  lg:bg-cover mt-16" w-800>
            <div class="bg-white">
                <p class="text-sm mx-5 text-black"><strong>NKCCG > </strong>
                    <strong>
                        Et vous, quelle équation voulez-vous résoudre ? >
                    </strong> <strong>Technologie : catalyseur de transformation et de compétitivité </strong>
                </p>
            </div>


            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class="  lg:ml-6  lg:mt-72 lg:mr-6 lg:px-20 lg:w-2/3">
                    <h1
                        class="text-4xl font-serif text-left ml-9 mr-14 mt-32 text-white inline-block bg-gray-800 px-4">
                        Technologie et performance
                    </h1>
                    <h1 class="text-xl font-serif text-left ml-9  text-white bg-gray-800 mr-32 px-4">

                        Faire de la technologie un catalyseur de transformation et de compétitivité
                    </h1>
                    <div class="ml-9  mt-2 mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>



                </div>

            </div>
            <div class="w-full bg-red-600 text-white px-auto mx-auto">
                <div class="grid gap-6 mb-6 md:grid-cols-3 mx-auto">
                    <div class="inline-block mt-5 ml-8">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">50 % </h1>
                        <p class="my-2 text-xl">des dirigeants prévoient d’investir dans la transformation digitale

                        </p>
                        <p class="text-sm my-5">Source : Etude NKCCG - Global CEO Survey 2021</p>

                    </div>

                    <div class="inline-block mt-5 mx-4">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem]"></div>
                        <h1 class="text-4xl">4 200 Mds de $</h1>
                        <p class="my-2 text-xl">de dépenses informatiques mondiales en 2021, soit 8,6 % de plus qu'en
                            2020

                        </p>

                        <p class="text-sm my-5">Source : Gartner Forecasts 2021 - Worldwide IT Spending</p>
                    </div>

                    <div class="inline-block mt-5 mx-4">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">56 % </h1>
                        <p class="my-2 text-xl">des dirigeants considèrent le cloud comme stratégique pour la
                            croissance et l'innovation

                        </p>

                        <p class="text-sm my-5">Source : NKCCG US Cloud Business Survey 2021</p>
                    </div>



                </div>
            </div>
        </section>
        <section class="lg:w-1/2 lg:mx-8 mx-6">




            <div>

                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">Investir dans la technologie
                    est déjà une priorité pour les dirigeants cherchant à accroître la performance et l’agilité de leur
                    entreprise – deux avantages compétitifs prédominants pour les dix prochaines années</p>
                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">Pour tirer parti des
                    opportunités offertes par des technologies telles que le <a nkccgbtnfile="HideSize"
                        href="#">cloud</a>, l’intelligence artificielle (IA), la robotic process automation (RPA)
                    ou encore la blockchain, les organisations doivent monter en compétence et transformer en profondeur
                    leur modèle opérationnel.</p>
                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5"> Au-delà des aspects
                    techniques, il est également crucial de se préoccuper des questions liées à l’éthique, la fiscalité
                    et la souveraineté. L’objectif commun est que ces évolutions vers un monde toujours plus connecté
                    soient vécues comme facteurs de progrès.</p>

            </div>



        </section>
        <section class=" py-10">

            <div class=" bg-gray-100 dark:bg-blacksection dark:border-strokedark  py-10">


                <h2 class="lg:text-4xl text-xl text-gray-800 lg:mx-8 mx-6 py-1 lg:px-10 mb-5   ">Assurer sa transformation grâce à la
                    technologie</h2>



                <div class=" lg:mx-12 mx-6 mt-5 lg:flex ">
                    <div class="lg:mr-6 mt-5 lg:w-1/3 ">
                        <button
                            class="flex items-center justify-between bg-red-700 h-16 lg:w-2/3 lg:ml-10 lg:px-4 border border-gray-400 mb-2">
                            <span class=" text-xl text-white">Se différencier par l’innovation</span>

                        </button>



                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">
                            Répondre aux ambitions de croissance et mettre en place de nouveaux business models
                        </p>
                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">Répondre aux ambitions de
                            croissance et mettre en place de nouveaux business models</p>



                        </p>


                    </div>
                    <div class=" lg:w-2/3 ">
                        <div class=" mt-5">
                            <h3 class="lg:text-4xl text-2xl font-bold text-gray-800 mb-5   lg:mx-7">Se différencier par l’innovation
                            </h3>
                            <p class="text-gray-800 leading-relaxed  tracking-wide   lg:mx-8 mb-4"> Innover pour faire face
                                à des défis majeurs – qu’ils soient environnementaux, sanitaires, économiques ou
                                sociétaux – implique de s’adapter et de prendre en compte tout l’écosystème lié à une
                                technologie. Innover, c’est parfois aussi travailler de manière collaborative avec ses
                                concurrents (coopétition au sein de consortiums ou conglomérats) afin de gagner en
                                agilité et en compétitivité.</p>



                        </div>



                    </div>




                </div>


            </div>

        </section>
        <section class="">

            <div class=" ">

                <h1 class="lg:text-4xl text-2xl text-gray-800 mx-5 mb-5 lg:ml-20">La technologie : un facteur clé de confiance</h1>


                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mx-12 mx-6">
                    <div class="lg:mr-6 mt-5 ">
                        <h2 class="lg:text-3xl text-xl font-bold text-gray-800 lg:mx-5 mb-5 ">Anticiper les menaces et préserver la
                            confiance</h2>

                        <div class=" mt-15">

                            <P class="text-gray-800 mb-5 leading-relaxed  tracking-wide lg:mx-8 text-xl">Les risques
                                auxquels les organisations sont confrontées sont chaque jour plus nombreux et plus
                                complexes : attaques par ransomwares, groupes malveillants, fuite de données... La
                                question n'est plus de savoir si elles seront impactées, mais quand. Pour assurer la
                                pérennité de l’activité et développer la confiance, l’anticipation permise par les
                                outils technologiques reste le meilleur moyen de défense. </P>
                        </div>

                        <h2 class="lg:text-3xl text-xl font-bold text-gray-800 lg:mx-5 mb-5 ">Développer sa résilience </h2>

                        <div class=" mt-15">

                            <P class="text-gray-800 mb-5 leading-relaxed  tracking-wide lg:mx-8 text-xl">Panne matérielle,
                                faute technique ou humaine, surcharge d’activité ou piratage informatique : des sources
                                de risque variées peuvent entraîner une paralysie voire une suspension de l’activité.
                                Adopter une infrastructure agile qui place la résilience au cœur de son modèle est
                                essentiel à la sécurité et au bon fonctionnement de l’entreprise. </P>
                        </div>


                    </div>
                    <div class="">
                        <div class="lg:mx-8 my-8">
                            <img class=" mb-5 " alt="" w- style="background-color: transparent;"
                                src="/images/African_workplace.png">
                        </div>




                    </div>




                </div>


            </div>

        </section>
        <section class="bg-gray-200 ">
            <div class="h-9"></div>
            <div class="  shadow-solid-13  ">
                <h2 class="fk vj zp   pr text-xl kk wm qb mx-6 lg:mx-24 text-gray-500 ">Pour aller plus loin
                </h2>
                <div class="w-full ">

                    <div class="lg:flex lg:mx-12 mx-6  justify-between ">
                        <div class=" ">
                            <img src="images/cq5dam.thumbnail.319.319.webp"
                                alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">


                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                Prospérer à l’ère de la réinvention <br> continue, 27e CEO Survey
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/cq5dam.thumbnai.webp"
                                alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">


                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                Sustainable Technology : le numérique<br> au service de la durabilité
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/cq5da.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">

                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                Vivatech et NKCCG
                            </p>

                        </div>
                        <div class="">
                            <div class="flex ">
                                <img src="images/cq5dam.tl.319.319.webp"
                                    alt="marketing-digital-service-création-de-site-web" class=" h-44 w-80 ">
                            </div>

                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                Tech Lab NKCCG
                            </p>


                        </div>
                    </div>
                    <a href="/#"
                        class="lg:flex gi lg:mt-4 w-32  mr-auto ml-auto border border-gray-800 text-gray-800 bg-transparent hover:bg-orange-600 hover:text-white block">
                        <span class="ml-9">Voir plus</span>
                        
                    </a>
                </div>
                <div class="h-6"></div>
            </div>

        </section>

        <section class="  bg-gray-100 py-5">

            <div class=" ">

                <p class="text-xl font-bold text-gray-400 leading-relaxed  tracking-wide mx-6 lg:mx-8 mb-5 mt-8">Quelles autres
                    équations voulez-vous résoudre ?</p>


                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mr-8 mx-6 lg:mx-0 lg:ml-8">
                    <div class=" mt-5 ">

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl">Transition écologique et sociétale</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>



                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl">Culture et responsabilité d'entreprise</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Création et préservation de valeur </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl">Croissance des entreprises familiales/ETI </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>



















                    </div>
                    <div class="">
                        <div class=" lg:mt-5">

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Technologie et performance</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Transparence et maîtrise des risques</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl">Transformation des business models</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl "> Startups et innovation </span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>






                        </div>



                    </div>




                </div>


            </div>

        </section>

        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>
        <section class=" lg:h-64 ">
            <div class="h-16 bg-yellow-600">
                <h1 class="text-3xl font-serif text-black mx-16">
                    Contactez-nous
                </h1>

            </div>
            <div class="flex items-center">
                <div class="flex lg:mx-16 mt-6">
                    <div class="flex ">
                        <img src="images/fr-france-800xage.jpg" alt="marketing-digital-service-création-de-site-web"
                            class=" ">
                    </div>
                    <div class=" ">
                        <h1 class="text-2xl mx-6 font-serif text-black">Rami Feghali</h1>
                        <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                            Associé Risques et réglementations FS,<br> NKCCG Bénin et Maghreb
                        </p>
                        <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                    </div>

                </div>

            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>

                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>


                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires

                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact

                            </a>
                        </li>

                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>

        </div>
        </div>

    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/technologie.blade.php ENDPATH**/ ?>