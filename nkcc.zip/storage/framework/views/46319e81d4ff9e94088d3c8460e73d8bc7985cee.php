<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->


    <!-- ===== Header End ===== -->

    <main>

        <section class=" bg-[url('/images/blog-4.jpg')]  lg:bg-cover mt-16" w-800>
            <div class="bg-white">
                <p class="text-sm mx-5 text-black"><strong>NKCCG > </strong>
                    <strong>
                        Et vous, quelle équation voulez-vous résoudre ? >
                    </strong> <strong>Les entreprises ETI </strong>
                </p>
            </div>


            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class="  lg:ml-6 mt-24 lg:mt-72 lg:mr-6 lg:px-20 lg:w-2/3">
                    <h1
                        class="text-4xl font-serif text-left ml-9 mr-14 mt-32 text-white inline-block bg-gray-800 px-4">
                        Entreprises de taille intermédiaire (ETI)

                    </h1>
                    <h1 class="text-xl font-serif text-left ml-9  text-white bg-gray-800 mr-32 px-4 inline-block">
                        Des équipes et outils dédiés NKCCG au service de votre développement
                    </h1>
                    <div class="ml-9  mt-2 mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>



                </div>

            </div>

        </section>
        <section class=" bg-gray-200 py-10">




            <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mx-8 mx-6">
                <div>

                    <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5 ">Motrices économiques,
                        actrices de l'intérêt général et source de cohésion sociale dans nos territoires, les
                        entreprises de taille intermédiaire (ETI) représentent un poids considérable dans l’économie
                        française. Elles génèrent 25 % de l’emploi, 34 % des exportations françaises et 75 % des sites
                        de production sont situés dans les villes moyennes ou en zone rurale.</p>
                    <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5 ">Les entreprises ETI
                        conquérantes doivent investir pour poursuivre leur croissance et leur transformation.</p>
                    <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">Impact sociétal et
                        environnemental, digitalisation, attractivité des talents, transmission et compétitivité font
                        partie de vos grands défis ? Pour répondre à vos enjeux, NKCCG a constitué une équipe de
                        spécialistes et des offres sur-mesure.</p>



                </div>
                <div>
                    <div class="flex justify-end ">
                        <img class=" mb-0 " alt="" style="background-color: transparent;"
                            src="/images/C1.jpg">
                    </div>
                </div>
            </div>

        </section>

        <section class=" py-10">
            <h1 class=" leading-relaxed lg:text-4xl text-2xl lg:ml-10 mx-6 lg:mx-0 mb-5 text-gray-800">Un accompagnement quelque soit votre <br>
                structure capitaliste</h1>


            <div class="grid gap-6 mb-6 md:grid-cols-3 lg:px-8">
                <div class="lg:px-5 mx-6 lg:mx-0">
                    <div class="flex items mb-4">
                        <img class=" " alt="" style="background-color: transparent;"
                            src="images/dashboard.svg">
                        <div>
                            <h3 class="font-bold lg:text-3xl text-xl text-gray-800 ml-5 mb-10 ">ETI côtés</h3>

                        </div>
                    </div>

                    <p class="text-gray-800 mb-5 leading-relaxed  tracking-wide  text-xl">Renforcement de la
                        gouvernance, formalisation accrue de l’évaluation des risques et de l’environnement de contrôle,
                        production d’informations financières et extra financières complémentaires, raccourcissement des
                        délais de clôture, et sur de nombreux autres enjeux, notre équipe vous apporte son expertise
                    </p>


                </div>
                <div class="lg:px-5 mx-6 lg:mx-0">
                    <div class="flex items mb-4">
                        <img class=" " alt="" style="background-color: transparent;"
                            src="images/community.svg">
                        <div>
                            <h3 class="font-bold g:text-3xl text-xl text-gray-800 ml-5 mb-10 ">ETI familiales</h3>

                        </div>
                    </div>

                    <p class="text-gray-800 mb-5 leading-relaxed  tracking-wide  text-xl">NKCCG accompagne les
                        dirigeants
                        des entreprises familiales sur les sujets de transmission et succession, gouvernance,
                        attractivité, fiscalité, risques, développement international, raisons d’être, etc. Pour ce
                        faire, NKCCG a développé l’Owner’s Agenda. Une approche dédiée aux enjeux de l'entreprise et des
                        actionnaires, adaptée aux valeurs et à la cultures des groupes familiaux. </p>

                </div>
                <div class="lg:px-5 mx-6 lg:mx-0">

                    <div class="flex items mb-4">
                        <img class=" " alt="" style="background-color: transparent;"
                            src="images/quality.svg">
                        <div>
                            <h3 class="font-bold g:text-3xl text-xl text-gray-800 ml-5 mb-10 ">ETI Private Equity</h3>

                        </div>
                    </div>

                    <p class="text-gray-800 mb-5 leading-relaxed  tracking-wide  text-xl">Sur de nombreuses
                        problématiques liées à la création de valeur (croissance externe, internationalisation,
                        digitalisation, transformation, RSE, conformité, financement, fiscalité, etc.), NKCCG aide les
                        ETI de l’écosystème Private Equity. Sur l’ensemble des sujets transactionnels à l’occasion de la
                        sortie de leur actionnaire financier, NKCCG accompagne également les sociétés de portefeuille.
                    </p>

                </div>
            </div>
        </section>
        <section>
            <div style="display: flex; justify-content: center;">
                <img class=" lg:h-[60rem]  " alt="" style="background-color: transparent;"
                    src="images/infographies.svg">
            </div>
        </section>

        <section class=" lg:py-10">

            <div class=" bg-gray-100 dark:bg-blacksection dark:border-strokedark  lg:py-10">


                <h2 class="lg:text-4xl text-2xl text-gray-800 lg:mx-8  mx-6 py-1 lg:px-10 mb-5   ">Accompagner les ETI sur l’ensemble de ses
                    <br> problématiques stratégiques et opérationnelles
                </h2>



                <div class=" lg:mx-12 mx-6 lg:mt-5 lg:flex ">
                    <div class="lg:mr-6 mt-5 lg:w-1/3 ">
                        <button
                            class="flex items-center justify-between bg-orange-600 lg:h-16  lg:ml-10 px-4 border border-gray-400 mb-2">
                            <span class=" text-xl text-white">Concevoir des business models à l’épreuve des
                                disruptions</span>

                        </button>



                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">
                            Créer plus de valeur avec des stratégies de croissance externe ou de cession
                        </p>
                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">Enrichir sa stratégie pour
                            répondre aux enjeux écologiques et sociétaux</p>
                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">Faire de la technologie un
                            catalyseur de transformation et de compétitivité</p>
                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">Faire de la technologie un
                            catalyseur de transformation et de compétitivité</p>
                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">Concilier performance et
                            responsabilité sociale de l’entreprise</p>



                        </p>


                    </div>
                    <div class=" lg:w-2/3">
                        <div class=" mt-5">
                            <h3 class="lg:text-4xl text-2xl font-bold text-gray-800 mb-5 lg:mx-7">Concevoir des business models à
                                l’épreuve des disruptions</h3>
                            <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-8">De l’adaptation de votre
                                structure de coûts au design de l’expérience idéale pour vos utilisateurs, l’équipe ETI
                                vous accompagne sur le diagnostic et la définition de la feuille de route de votre
                                Direction Financière, l’accélération et la mise en qualité de votre processus de
                                clôture, le pilotage de vos performances, la sélection de votre futur ERP ainsi que sur
                                des diagnostics Supply Chain / Opérations. Aussi, l’équipe ETI vous guidera sur tous les
                                enjeux que vous rencontrez liés à l'optimisation de la performance de vos achats.</p>

                            <a href="/#"
                                class="flex gi lg:mt-4 lg:w-96 lg:ml-8   text-white bg-orange-600 hover:bg-white hover:text-gray-800 border border-gray-800 block">
                                <span class="ml-9 font-bold mr-6">Transformation des business models</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor"
                                    class="w-4 h-4 mt-1 hover:text-orange-500">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </a>

                        </div>



                    </div>




                </div>


            </div>

        </section>
        <section class=" lg:py-10 mt-4 lg:mt-0">
            <h1 class=" lg:text-4xl text-2xl mx-6 lg:mx-0 lg:ml-10 text-gray-800">ETI : comment vous aider à créer de la <br> confiance et mener
                des transformations<br> complexes pour des résultats durables ?</h1>

        </section>

        <section class="bg-orange-600">
            <!-- Bg Shape -->
            <div class="flex   lg:h-44 lg:mx-64 mx-6">
                <img src="images/go-there-white.webp" class="h-24 mt-6">

                <div class="ml-6">

                    <p class="text-white lg:ml-4 mt-6 ">
                        Découvrez
                    </p>
                    <a href="/contact" class="flex  gi lg:mt-1 lg:ml-4  text-white lg:text-3xl text-lg inline-block">
                        <span class="">Startups et Innovation</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h-9 mt-0    mr-24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>

            </div>
        </section>

        <section class="">
            <div class="h-9"></div>
            <div class="  shadow-solid-13  ">
                <h2 class="fk vj zp   pr text-xl kk wm qb mx-6 lg:mx-24 text-gray-500 ">Pour aller plus loin
                </h2>
                <div class="w-full ">

                    <div class="grid gap-6 mb-6 md:grid-cols-4 px-8 mb-5">
                        <div class=" ">
                            <img src="images/image-3.jpg" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">


                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Prospérer à l’ère de la réinvention <br> continue, 27e CEO Survey
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/image-9.jpg" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">


                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Entreprises familiales : engagées pour un futur durable

                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/image-6.jpg" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">

                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">

                                eMag ETI - Décembre 2021 - N°1
                            </p>

                        </div>
                        <div class="">
                            <div class="flex ">
                                <img src="images/image-8.jpg" alt="marketing-digital-service-création-de-site-web"
                                    class=" h-44 w-80 ">
                            </div>

                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                eMag ETI - Avril 2022 - N°2

                            </p>


                        </div>
                    </div>
                    <div class="grid gap-6 mb-6 md:grid-cols-4 px-8 mt-5">
                        <div class=" ">
                            <img src="images/image-5.jpg" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">


                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Où nous trouver ?
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/image-7.jpg" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">


                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Entreprises familiales

                            </p>

                        </div>


                    </div>
                    
                </div>
                <div class="h-6"></div>
            </div>

        </section>

        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>
        <section class=" lg:h-64 ">
            <div class="h-16 bg-yellow-600">
                <h1 class="text-3xl font-serif text-black mx-16">
                    Contactez-nous
                </h1>

            </div>
            <div class="flex items-center">
                <div class="flex lg:mx-16 mt-6">
                    <div class="flex ">
                        <img src="images/fr-france-800xage.jpg" alt="marketing-digital-service-création-de-site-web"
                            class=" ">
                    </div>
                    <div class=" ">
                        <h1 class="text-2xl mx-6 font-serif text-black">Rami Feghali</h1>
                        <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                            Associé Risques et réglementations FS,<br> NKCCG Bénin et Maghreb
                        </p>
                        <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                    </div>

                </div>

            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>

                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>


                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires

                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact

                            </a>
                        </li>

                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>

        </div>
        </div>

    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/croissance.blade.php ENDPATH**/ ?>