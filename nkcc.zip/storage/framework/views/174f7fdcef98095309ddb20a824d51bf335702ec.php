<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->


    <!-- ===== Header End ===== -->

    <main>

        <section class=" bg-[url('/images/blog-1.jpg')]  lg:bg-cover mt-16" w-800>
            <div class="bg-white">
                <p class="text-sm mx-5 text-black"><strong>NKCCG > </strong>
                    <strong>
                        Et vous, quelle équation voulez-vous résoudre ? >
                    </strong> <strong>Confiance : transparence et maîtrise des risques </strong>
                </p>
            </div>


            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class="  lg:ml-6  mt-72 lg:mr-6 lg:px-20 lg:w-2/3">
                    <h1
                        class="text-4xl font-serif text-left ml-9 mr-14 mt-32 text-white inline-block bg-gray-800 px-4">
                        Transparence et maîtrise des risques
                    </h1>
                    <h1 class="text-xl font-serif text-left ml-9  text-white bg-gray-800 mr-32 px-4">
                        Intégrer transparence et maîtrise des risques pour renforcer la confiance
                    </h1>
                    <div class="ml-9  mt-2 mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>



                </div>

            </div>
            <div class="w-full bg-red-600 text-white px-auto mx-auto">
                <div class="grid gap-6 mb-6 md:grid-cols-3 mx-auto">
                    <div class="inline-block mt-5 ml-8">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">75 %</h1>
                        <p class="my-2 text-xl">des organisations en France ont connu au moins une crise au cours des 5
                            dernières années

                        </p>
                        <p class="text-sm my-5">Source : Etude NKCCG - Gestion de crise et résilience des SI</p>

                    </div>

                    <div class="inline-block mt-5 mx-4">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem]"></div>
                        <h1 class="text-4xl">73 %</h1>
                        <p class="my-2 text-xl">des organisations pensent que leur exposition aux risques s’intensifie

                        </p>

                        <p class="text-sm my-5">Source : NKCCG 2020 - Global Risk Survey</p>
                    </div>

                    <div class="inline-block mt-5 mx-4">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">70 %</h1>
                        <p class="my-2 text-xl">des organisations prévoient d'augmenter leurs investissements afin
                            d’accroître leur résilience

                        </p>

                        <p class="text-sm my-5">Source : NKCCG Global Crisis Survey 2021</p>
                    </div>



                </div>
            </div>
        </section>
        <section class="lg:w-1/2 lg:mx-8 mx-6">




            <div>

                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">La pandémie de Covid-19, en
                    créant des risques nouveaux en l’absence de mécanismes institutionnels stabilisateurs, a mis en
                    évidence la vulnérabilité des entreprises dans de multiples dimensions. Il leur est désormais
                    impératif d’être capable de s’adapter à un environnement plus risqué et plus complexe à appréhender.
                </p>
                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl ">Les dispositifs de gestion des
                    risques doivent opérer une double transformation. D’une part, ils deviennent plus stratégiques,
                    holistiques et prospectifs pour mieux anticiper et permettre aux entreprises de se préparer. D’autre
                    part, ils doivent améliorer la résilience et leur efficacité pour pouvoir réagir rapidement et
                    surmonter les crises importantes.</p>
                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">Enfin, dans un contexte
                    incertain, communiquer avec transparence vis-à-vis de l'ensemble des parties prenantes est
                    nécessaire.</p>

            </div>



        </section>
        <section class="bg-gray-100 py-10">
            <h1 class=" text-4xl ml-10 text-gray-800">Préparation à la CSRD : les résultats de la<br> collaboration
                entre Michelin et NKCCG</h1>
            <div class=" grid gap-6 mb-6 md:grid-cols-2 mx-auto">
                <div class="mt-10">
                    <h3 class="font-bold text-2xl text-gray-800 ml-10 mb-1 ">Video</h3>
                    <p class="ml-10 mb-5">Veuillez accepter tous les cookies pour visionner cette vidéo.</p>

                    <div class="flex justify-center items-center">
                        <button type="button"
                            class=" py-2.5 px-5 me-2 mb-2  text-lg font-bold text-gray-900 text-center focus:outline-none bg-transparent border border-gray-400 hover:bg-gray-500 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-200 ">Paramètres
                            des cookies</button>
                    </div>
                </div>
                <div>
                    <p class="text-gray-800 mb-5 leading-relaxed  tracking-wide mx-8 text-xl mb-5">Dans un contexte
                        d'évolution réglementaire rapide et d'exigences croissantes en matière de reporting de
                        durabilité, le Groupe Michelin a fait confiance à NKCCG pour l'accompagner dans la
                        sensibilisation
                        de plus de 120 collaborateurs aux enjeux de la CSRD (Corporate Sustainability Reporting
                        Directive). </p>
                    <p class="text-gray-800 mb-5 leading-relaxed  tracking-wide mx-8 text-xl mb-5">Face à un calendrier
                        d'application strict et à des textes réglementaires en constante évolution, NKCCG a été choisi
                        pour mobiliser les contributeurs internes de Michelin, mesurer les écarts et apporter son
                        expertise pour identifier les pistes de chantier à mener. Cette collaboration a permis de
                        catalyser l'intelligence collective, préparant Michelin à un avenir durable et à la conformité
                        réglementaire. </p>

                </div>
            </div>
        </section>
        <section class="">

            <div class="py-10 lg:ml-10 mx-6">


                <h2 class="lg:text-4xl text-2xl text-gray-800 lg:mx-5 mb-5 ">Construire la confiance grâce à plus de <br> transparence
                </h2>

                <div class=" mb-6 lg:flex lg:mx-12 ">
                    <div class="lg:mr-6 mt-5 lg:w-1/2 ">


                        <div class=" mt-1">

                            <h3 class="text-2xl font-bold text-gray-800 mb-5 lg:mx-7">Communiquer avec transparence</h3>

                            <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8  text-xl ">Le besoin de
                                confiance est plus fort que jamais. Les entreprises doivent alors réussir à communiquer
                                de manière transparente sur leurs activités, leurs risques et leurs engagements,
                                d’autant plus que la pression réglementaire sur cette communication est de plus en plus
                                forte. Avoir un dispositif de reporting robuste devient incontournable pour s’assurer de
                                la fiabilité de l’information communiquée aux différentes parties prenantes.</p>

                        </div>
                    </div>
                    <div class="lg:w-1/2">
                        <div class="lg:mx-8 my-8 ">
                            <img class=" mb-0 " alt="" w- style="background-color: transparent;"
                                src="/images/African_workplace.png">
                        </div>




                    </div>




                </div>


            </div>

        </section>
        <section class=" py-10">

            <div class=" bg-gray-100 dark:bg-blacksection dark:border-strokedark  py-10">


                <h2 class="lg:text-4xl text-xl text-gray-800 lg:mx-8 py-1 lg:px-10 mb-5 mx-6 ">Assurer sa transformation et sa résilience
                    grâce à la<br> gestion des risques</h2>



                <div class=" lg:mx-12 mt-5 lg:flex ">
                    <div class="lg:mr-6 mt-5 lg:w-1/3 mx-6 lg:mx-0">
                        <button
                            class= "mb-2 flex items-center justify-between bg-red-700 h-16  lg:ml-10 px-4 border border-gray-400 mb-2">
                            <span class=" text-xl text-white">Simuler les risques pour mieux anticiper</span>

                        </button>
                        <p class="text-center text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">Accroître la
                            résilience et l’efficacité</p>



                        </p>


                    </div>
                    <div class=" lg:w-2/3">
                        <div class=" mt-5">
                            <h3 class="lg:text-4xl text-2xl font-bold text-gray-800 mb-5 mx-6 lg:mx-7">Simuler les risques pour mieux
                                anticiper</h3>
                            <p class="text-gray-800 leading-relaxed  tracking-wide mx-8 mb-4">Aujourd’hui, l’enjeu en
                                matière de gestion des risques est de développer une analyse prospective des risques
                                afin de mieux anticiper les prochaines crises et évolutions majeures. Les organisations
                                peuvent faire évoluer leur approche des risques avec l’analyse de scénarios et une
                                meilleure exploitation des données grâce à la technologie. </p>




                        </div>



                    </div>




                </div>


            </div>

        </section>

        <section class="">
            <div class="lg:h-9"></div>
            <div class="  shadow-solid-13  ">
                <h2 class="fk vj zp   pr text-xl kk wm qb  mx-24 text-gray-500 ">Pour aller plus loin
                </h2>
                <div class="w-full ">

                    <div class="lg:flex lg:mx-12 mx-6 justify-between ">
                        <div class=" ">
                            <img src="images/cq5dam.thumbnail.319.319.webp"
                                alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">


                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Prospérer à l’ère de la réinvention <br> continue, 27e CEO Survey
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/cq5dam.thumbnai.webp"
                                alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">


                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Et si la sécurité était<br> au cœur de l'innovation ?
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/cq5da.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">

                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Global Crisis and Resilience <br> Survey 2023
                            </p>

                        </div>
                        <div class="">
                            <div class="flex ">
                                <img src="images/cq5dam.tl.319.319.webp"
                                    alt="marketing-digital-service-création-de-site-web" class=" h-44 w-80 ">
                            </div>

                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                L’Résilience des Systèmes<br> d’Information
                            </p>


                        </div>
                    </div>
                    
                </div>
                <div class="h-6"></div>
            </div>

        </section>

        <section class=" py-5 bg-gray-100">

            <div class=" ">

                <p class="text-xl font-bold text-gray-400 leading-relaxed  tracking-wide lg:mx-8 mx-6 mb-5 mt-8">Quelles autres
                    équations voulez-vous résoudre ?</p>


                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mr-8 mx-6 lg:mx-0 lg:ml-8">
                    <div class=" mt-5 ">

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Transition écologique et sociétale</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>



                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Culture et responsabilité d'entreprise</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Création et préservation de valeur </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Croissance des entreprises familiales/ETI </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                    </div>
                    <div class="">
                        <div class=" lg:mt-5 mt-0">

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Technologie et performance</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Transparence et maîtrise des risques</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl">Transformation des business models</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl"> Startups et innovation </span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>






                        </div>



                    </div>




                </div>


            </div>

        </section>


        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>
        <section class=" lg:h-64 ">
            <div class="h-16 bg-yellow-600">
                <h1 class="text-3xl font-serif text-black mx-16">
                    Contactez-nous
                </h1>

            </div>
            <div class="flex items-center">
                <div class="flex lg:mx-16 mt-6">
                    <div class="flex ">
                        <img src="images/fr-france-800xage.jpg" alt="marketing-digital-service-création-de-site-web"
                            class=" ">
                    </div>
                    <div class=" ">
                        <h1 class="text-2xl mx-6 font-serif text-black">Rami Feghali</h1>
                        <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                            Associé Risques et réglementations FS,<br> NKCCG Bénin et Maghreb
                        </p>
                        <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                    </div>

                </div>

            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>

                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>


                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires

                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact

                            </a>
                        </li>

                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>

        </div>
        </div>

    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/transparence.blade.php ENDPATH**/ ?>