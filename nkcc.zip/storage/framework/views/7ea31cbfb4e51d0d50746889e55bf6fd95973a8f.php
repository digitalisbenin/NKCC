<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->

    <!-- ===== Header End ===== -->

    <main>

        <section class=" bg-[url('/images/employees.jpg')]  lg:bg-cover mt-16" w-800>
            <div class="bg-white">
                <p class="text-base mx-5 text-black"><strong>NKCCG > </strong>
                    <strong>
                        Nos expertises >
                    </strong> <strong>Audit </strong>
                </p>
            </div>
            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class="  lg:ml-6 mt-32 lg:mt-72 lg:mr-6 lg:px-20 lg:w-2/3">
                    <h1
                        class="lg:text-4xl text-2xl font-serif text-left ml-9 mr-14 mt-32 text-white inline-block bg-gray-800 px-4">
                        Audit
                    </h1>
                    <h1 class="text-xl font-serif text-left ml-9  text-white bg-gray-800 lg:mr-64 mr-32 px-4">

                        Apporter de la confiance et vous aider à créer de la valeur
                    </h1>
                    <div class="ml-9  mt-4 mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>



                </div>

            </div>
            <div class="w-full bg-red-600 text-white px-auto mx-auto">
                <div class="grid gap-6 mb-6 md:grid-cols-4 mx-auto">
                    <div class="inline-block mt-5 ml-8">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">11 000+ </h1>
                        <p class="my-2 text-xl">mandats réalisés en France

                        </p>


                    </div>

                    <div class="inline-block mt-5 ml-8 lg:ml-0 lg:mx-4">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem]"></div>
                        <h1 class="text-4xl">16</h1>
                        <p class="my-2 text-xl">sociétés du CAC 40 et 39 du SBF120 auditées par NKCCG au Bénin

                        </p>


                    </div>

                    <div class="inline-block mt-5 ml-8 lg:ml-0 lg:mx-4">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">2 000+ </h1>
                        <p class="my-2 text-xl">PME accompagnées à travers nos 14 bureaux au Bénin

                        </p>


                    </div>

                    <div class="inline-block mt-5 mx-4">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">2 500+ </h1>
                        <p class="my-2 text-xl">Associés et collaborateurs

                        </p>

                    </div>

                </div>
            </div>
        </section>
        <section class="mx-6 lg:mx-8">


            <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mx-12 ">

                <div>
                    <h2 class="text-4xl text-gray-800 lg:mx-5 mb-10 ">L'audit par NKCCG</h2>
                    <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">Notre métier d’audit et
                        de commissariat aux comptes, en certifiant la qualité et la fiabilité de vos informations
                        financières, est un gage de transparence et donc de confiance pour vos parties prenantes et
                        contribue ainsi à votre croissance. C’est pourquoi nous avons à cœur de vous apporter un service
                        personnalisé et toujours à la pointe des réglementations.</p>
                    <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">Parce que vos enjeux sont
                        souvent liés à vos spécificités, notre positionnement est le fruit d’une approche
                        sectorielle.&nbsp;Nos équipes vous apportent ainsi leur vision prospective des <u><a
                                href="https://www.NKCCG.fr/fr/industries.html" target="_blank"
                                adhocenable="false">tendances de votre secteur</a></u>, leur compréhension de votre
                        environnement, des risques associés et de leurs conséquences sur l’information financière.</p>

                </div>

                <div class="lg:mt-7">
                    <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5 mt-10">Partenaire
                        essentiel de la vie économique locale dans 14 villes, NKCCG fait bénéficier les acteurs régionaux
                        de la force de son réseau international et leur garantit à la fois les moyens et la puissance
                        d’une organisation globale, mais aussi la compréhension et la prise en compte du contexte local.
                    </p>
                    <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl">Forts de la diversité et de la
                        complémentarité de nos métiers, nous sommes à même de répondre à la complexité de vos enjeux en
                        mobilisant toutes nos expertises (techniques, juridique, fiscal, marchés de capitaux, data…).
                        Nous avons à cœur de vous proposer un accompagnement sur mesure, un accompagnement qui va plus
                        loin que la revue des risques comptables et financiers de votre entreprise.</p>
                </div>
            </div>
        </section>
        <section class=" lg:py-10">

            <div class=" bg-gray-200  ">


                <h2 class="lg:text-4xl text-2xl text-gray-800 mx-6 lg:mx-8 py-5 lg:px-10 mb-10 ">Vos enjeux</h2>

                <div class="justify items-center mx-6 lg:ml-20">
                    <button type="button"
                        class="py-2.5 px-5 me-2 mb-2 text-sm font-medium text-white focus:outline-none bg-gray-600 rounded-full border border-black hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100">Data
                        Intelligence</button>

                    <button type="button"
                        class="py-2.5 px-5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-transparent rounded-full border border-black hover:bg-gray-600 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-100">Cybersécurité</button>
                    <button type="button"
                        class="py-2.5 px-5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-transparent rounded-full border border-black hover:bg-gray-600 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-100">Opérations
                        financières</button>
                    <button type="button"
                        class="py-2.5 px-5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-transparent rounded-full border border-black hover:bg-gray-600 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-100">Gestion
                        des risques</button>
                    <button type="button"
                        class="py-2.5 px-5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-transparent rounded-full border border-black hover:bg-gray-600 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-100">Reporting
                        RSE</button>



                </div>

                <div class="grid gap-6 mb-6 md:grid-cols-2 mx-6 lg:mx-12 mt-10 ">
                    <div class="lg:mr-6 lg:mt-5 ">

                        <h3 class="lg:text-4xltex-2xl font-bold text-gray-800 mb-5 lg:mx-7">Data Intelligence</h3>
                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">
                            Comment exploiter les données et les analyser efficacement pour apporter plus de valeur à
                            votre entreprise ?
                        </p>
                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">L’afflux de données toujours
                            plus important offre aux dirigeants l’opportunité d’en apprendre plus sur leur entreprise,
                            leurs clients, leurs employés, les marchés sur lesquels ils opèrent.</p>
                        <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 lg:mb-20 mb-6">Toutefois, la plupart
                            d’entre eux n’exploite qu’une infime partie des données dont ils disposent …</p>


                        </p>
                        <button type="button"
                            class="py-2.5 px-5 me-2 mb-15 lg:mx-8 lg:my-10 text-lg font-medium text-gray-600 focus:outline-none bg-transparent border border-gray-600 hover:bg-orange-600 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-200 ">En
                            savoir plus</button>

                    </div>
                    <div class="">
                        <div class=" mt-2">

                            <div class="lg:mx-8">
                                <img class=" mb-5 " alt="" w- style="background-color: transparent;"
                                src="images/fr-france-670x377-shutterstock_40872040620240221.webp">
                            </div>

                        </div>



                    </div>




                </div>


            </div>

        </section>
        <section class="">

            <div class=" ">




                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mx-12 mx-6 ">
                    <div class="lg:mr-6 lg:mt-5 ">
                        <h2 class="lg:text-4xl text-2xl text-gray-800 lg:mx-5 mb-5 ">Changer votre regard sur l’audit</h2>

                        <div class=" lg:mt-15">

                            <P class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl">Dans un contexte de
                                transformation, et en particulier en matière technologique, NKCCG s’est engagé depuis
                                plusieurs années dans le développement d’outils destinés à améliorer la pertinence et la
                                qualité de nos audits, renforcer notre collaboration et offrir un audit plus digitalisé
                                à nos clients et nos équipes.</P>
                        </div>
                    </div>
                    <div class="">
                        <div class="lg:mx-8 my-8">
                            <img class=" mb-5 " alt="" w- style="background-color: transparent;"
                                src="/images/African_workplace.png">
                        </div>




                    </div>




                </div>


            </div>

        </section>

        <section class="  bg-gray-100 py-5">

            <div class=" ">

                <p class="text-xl font-bold text-gray-400 leading-relaxed mx-6 tracking-wide lg:mx-8 mb-5 mt-8">Actualité
                    réglementaire</p>


                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mr-8 mx-6 lg:mx-0 lg:ml-8">
                    <div class=" lg:mt-5 ">

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">IFRS et Règles Françaises</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>



                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl "> Protection des données personnelles - RGPD</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent lg:h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Taxinomie verte européenne </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>












                    </div>
                    <div class="">
                        <div class=" lg:mt-5">

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl">Loi Sapin 2</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Risques et réglementations dans les services
                                    financiers</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>






                        </div>



                    </div>




                </div>


            </div>

        </section>
        <section class="bg-gray-100 ">
            <div class="h-9"></div>
            <div class="  shadow-solid-13  ">
                <h2 class="fk vj zp   pr text-xl kk wm qb mx-6  lg:mx-24 ">Nos clients témoignent
                </h2>
                <div class="w-full ">

                    <div class="lg:flex lg:mx-24 mx-6 justify-between ">
                        <div class=" ">
                            <img src="images/cq5.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">

                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                29/06/20
                            </p>
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                Accompagner un grand groupe<br> du secteur du transport
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/abhj.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">

                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                28/03/18
                            </p>
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                Accompagner l’introduction <br> en bourse de L’Occitane
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/cq5da.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                01/02/2024
                            </p>
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                Accompagner le développement <br> de la start-up Pretty Simple
                            </p>

                        </div>
                        <div class="">
                            <div class="flex ">
                                <img src="images/tnbyfvc.webp" alt="marketing-digital-service-création-de-site-web"
                                    class=" h-44 w-80 ">
                            </div>

                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                21/02/18
                            </p>
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                Auditer Agrial à l’international
                            </p>


                        </div>
                    </div>

                </div>
                <div class="h-6"></div>
            </div>

        </section>

        <section class="bg-red-600">
            <!-- Bg Shape -->
            <div class="flex   lg:h-44 lg:mx-64 mx-6">
                <img src="images/go-there-white.webp" class="h-24 mt-6 mr-10">

                <div class="">

                    <p class="text-white lg:ml-4 mt-6 ">
                        NKCCG France et Maghreb partenaire fondateur
                    </p>
                    <a href="/contact" class="flex  gi lg:mt-1 lg:ml-4  text-white lg:text-3xl  text-lg block">
                        <span class=" ">Performance Globale Multi-Capitaux : découvrez la chaire
                            Audencia</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h-9 ">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>

            </div>
        </section>


        <section class="">

            <div class=" bg-gray-100 py-10 ">




                <div class="grid gap-6 mb-6 md:grid-cols-4 lg:mx-12 mx-6">
                    <div class=" mt-5 ">
                        <p class="font-bold text-gray-500 mb-2 text-xl">Pour aller plus loin</p>
                        <img src="images/8.webp" alt="" class="mb-2">


                        <p class="text-xl text-gray-800">Les rendez-vous du reporting de durabilité</p>
                    </div </div>
                    <div class="">

                        <img src="images/abhj.webp" alt="" class="mt-12 mb-2">


                        <p class="text-xl text-gray-800">Audit à distance – De la crise à des nouveaux leviers de mise
                            en œuvre des plans d’audit interne</p>


                    </div>

                </div>


            </div>


        </section>

        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>
        <section class=" lg:h-64 ">
            <div class="h-16 bg-yellow-600">
                <h1 class="text-3xl font-serif text-black mx-16">
                    Contactez-nous
                </h1>
    
            </div>
            <div class="flex items-center">
                <div class="flex lg:mx-16 mt-6">
                    <div class="flex ">
                        <img src="images/fr-france-800xage.jpg" alt="marketing-digital-service-création-de-site-web"
                            class=" ">
                    </div>
                    <div class=" ">
                        <h1 class="text-2xl mx-6 font-serif text-black">Rami Feghali</h1>
                        <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                            Associé Risques et réglementations FS,<br> NKCCG Bénin et Maghreb
                        </p>
                        <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                    </div>
    
                </div>
    
            </div>
        </section>
    
    
    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">
    
        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>
    
                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>
    
    
                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>
    
                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires
    
                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>
    
                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact
    
                            </a>
                        </li>
    
                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>
    
        </div>
        </div>
    
    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/audit.blade.php ENDPATH**/ ?>