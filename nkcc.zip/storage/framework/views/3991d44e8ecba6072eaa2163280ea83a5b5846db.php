<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->



    <!-- ===== Header End ===== -->

    <main>
        <section class=" bg-[url('/images/employees.jpg')]  mt-16 ">
            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class="  lg:ml-6 mx-4 lg:mt-64 mt-24 lg:mr-6 lg:px-20 h-96">
                    <h1 class="lg:text-4xl text-xl font-serif lg:text-left lg:ml-9 lg:mt-32 text-white bg-black px-4">
                        Prospérer à l’ère de la réinvention continue
                    </h1>
                    <h1 class="lg:text-4xl text-xl font-serif text-left lg:ml-9 mt-4 text-white bg-black mr-64 px-4">
                        CEO Survey - 27e édition
                    </h1>
                    <div class="lg:ml-9  mt-4">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="lg:w-9 lg:h- w-6 text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>
                    <a href="/contact"
                        class=" flex gi mt-4 w-44 lg:ml-9 text-white bg-black hover:bg-blue-700  block  lg:text-center">
                        <span class="ml-9">En savoir plus</span> <svg xmlns="http://www.w3.org/2000/svg"
                            fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="w-4 h-4 mt-1">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>

                </div>

            </div>

        </section>
        <section class="  justify-start">

            <div class=" mb-6  shadow-solid-13 bg-gray-200 dark:bg-blacksection dark:border-strokedark ">
                <h2 class="fk vj zp   pr text-xl kk wm qb  lg:ml-32 ">A la une
                </h2>
                <div class="w-full">
                    <div class="">
                        <div class="lg:flex  justify-between ">
                            <div class="mr-6 ">
                                <img src="images/groupe-afro-americains-travaillant-ensemble_1303-8983.webp"
                                    alt="marketing-digital-service-création-de-site-web" class="h-96  lg:mx-9">
                                <p class=" text-sm  lg:text-2xl text-black font-bold mt-6 ml-2 lg:ml-0">
                                    Le gong de la reprise M&amp;A a sonné. Etes-vous prêts ?


                                </p>
                                <p class=" text-sm text-center lg:text-lg ml-2 lg:ml-0  mt-4 text-gray-600">
                                    Résultats de l&#39;étude Global M&amp;A Industry Trends 2024
                                </p>

                            </div>
                            <div class="">
                                <div class="flex justify-end">
                                    <img src="images/African_workplace.png"
                                        alt="marketing-digital-service-création-de-site-web"
                                        class=" h-96 w-full  lg:mr-12">
                                </div>
                                <p class=" text-sm  text-center lg:text-2xl text-black font-bold mt-6">
                                    2024 : l’économie béninoise à la recherche de facteurs de réassurance


                                </p>
                                <p class=" text-sm text-center lg:text-lg  mt-4 text-gray-600">
                                    Décryptage économique #10 - Janvier 2024
                                </p>


                            </div>




                        </div>



                    </div>






                </div>
            </div>

        </section>
        <section class="text-center">
            <!-- Bg Shape -->
            <div class="w-full">
                <img src="images/fr-france-paris-2024-200-logos.svg">
                <a href="/#"
                    class="flex  gi lg:mt-4 w-44 mr-auto ml-auto  text-white bg-orange-600 hover:bg-blue-700 block">
                    <span class="ml-9">En savoir plus</span>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="w-4 h-4 mt-1">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                    </svg>
                </a>
            </div>
        </section>
        <section class="mt-6 bg-yellow-500">
            <!-- Bg Shape -->
            <div class="lg:flex   lg:h-80 lg:mx-24">

                <div class="lg:w-1/3 ">
                    <h1 class="text-2xl font-serif lg:text-left ml-9 mt-9 text-black">
                        Événements
                    </h1>
                    <p class="text-black ml-9 mt-6 lg:mr-24">
                        A travers des événements et des webcasts réguliers, décryptons ensemble l'actualité
                        d'aujourd'hui et les tendances de demain.
                    </p>
                    <a href="/#"
                        class="flex  gi lg:mt-9 mt-4 ml-9 w-44 text-black border border-black hover:bg-blue-700 block">
                        <span class="ml-9">Je décrouvre</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>
                <div class="lg:w-1/3 ">
                    <h1 class="text-2xl font-serif lg:text-left ml-9 mt-9 text-black">
                        Espace presse
                    </h1>
                    <p class="text-black ml-9 mt-6 lg:mr-24">
                        L'essentiel de l'actualité au Bénin.
                    </p>
                    <a href="/#"
                        class="flex  gi lg:mt-9 mt-4 ml-9 w-44 text-black border border-black hover:bg-blue-700 block">
                        <span class="ml-9">Je m'informe</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>
                <div class=" lg:w-1/3">
                    <h1 class="text-2xl font-serif lg:text-left ml-9 mt-9 text-black">
                        Vivatech
                    </h1>
                    <p class="text-black ml-9 mt-6 lg:mr-24">
                        Découvrez tous les replays
                    </p>
                    <a href="/#"
                        class="flex  gi lg:mt-9 mt-4 ml-9 w-44 text-black border border-black hover:bg-blue-700 block">
                        <span class="ml-9">Je décrouvre</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>
            </div>
        </section>
        <section class="bg-orange-600">
            <!-- Bg Shape -->
            <div class="flex h-44 lg:mx-64 ">
                <img src="images/icon_phone.webp" class="h-24 mt-6">

                <div class="">

                    <p class="text-white ml-4 mt-6 ">
                        Un besoin ? Une demande ?
                    </p>
                    <a href="/contactez" class="flex  gi lg:mt-4 lg:ml-4  text-white text-3xl   block">
                        <span class="">Contactez-nous</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h-9 mt-">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>

            </div>
        </section>
        <section class="">
            <div class="lg:mx-64 mx-6">
                <h1 class="text-4xl font-serif text-left  mt-9 text-black">
                    Alerte à la fraude
                </h1>
                <p class="text-black text-xl mt-6 lg:mr-24">
                    Nous attirons votre attention sur une pratique actuelle de personnes usurpant l’identité de
                    professionnels des grands cabinets d’audit technique et de conseil (dont NKCCG) auprès de
                    leurs clients ou de tiers afin d’obtenir auprès d’eux des informations sensibles (« Phishing ») ou
                    le paiement de fausses factures (« Escroquerie »).
                </p>
                <a href="/#"
                    class="flex  gi lg:mt-9  w-44 text-black border border-black hover:bg-blue-700 block">
                    <span class="ml-9">En savoir plus</span>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="w-4 h-4 mt-1">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                    </svg>
                </a>
            </div>

        </section>
        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>

                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>


                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires

                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact

                            </a>
                        </li>

                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>

        </div>
        </div>

    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/welcome.blade.php ENDPATH**/ ?>