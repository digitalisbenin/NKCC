<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->

 

    <!-- ===== Header End ===== -->

    <main>
        <section class=" bg-[url('/images/Sanstitre22.jpg')]  lg:bg-cover mt-16 ">
            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class=" lg:mt-52 mt-32 lg:mr-6 lg:px-20 lg:w-2/3 bg-gray-800">
                    <h1 class="lg:text-4xl text-2xl font-serif text-left ml-9 mt-12 text-white ">
                        Ingénierie et Construction
                    </h1>
                    <p class="lg:text-2xl text-xl font-serif text-left ml-9 mt-4 text-white">
                        Traditionnellement confronté à de faibles marges et à des niveaux de risques importants, le
                        secteur de l’ingénierie et de la construction doit faire face à de nouveaux défis tout en
                        restant largement dépendant des budgets d’investissement de l’Etat et des collectivités
                        publiques.
                    </p>
                    <div class="ml-9 mb-6 mt-4">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>


                </div>

            </div>

        </section>
        <section class=" bg-red-500">
            <!-- Bg Shape -->
            <div class="lg:flex   lg:h-54 lg:mx-24">
                <div class="h-6 lg:h-0"></div>
                <div class="lg:w-1/3 ">
                    <div class="border-t-4 border-white lg:mt-6 ml-9 w-12"></div>
                    <h1 class="text-4xl font-serif text-left ml-9 mt-9 text-white">
                        23,1 %

                    </h1>
                    <p class="text-white ml-9 mt-6 ">
                        de croissance annuelle de la taille du marché des Smart Cities de 2017 à 2022
                    </p>
                    <p class="text-white ml-9 mt-9 mr-24">
                        Source : Paris Région
                    </p>
                </div>
                <div class="lg:w-1/3 ">
                    <div class="border-t-4 border-white mt-6 ml-9 w-12"></div>
                    <h1 class="text-4xl font-serif text-left ml-9 mt-9 text-white">
                        43 %



                    </h1>
                    <p class="text-white ml-9 mt-6 ">
                        des entreprises françaises ont souscrit à des services de Threat Intelligence
                    </p>
                    <p class="text-white ml-9 mt-9 mr-24">
                        Source : La construction à l’heure de la cybercriminalité
                    </p>
                </div>
                <div class="lg:w-1/3 ">
                    <div class="border-t-4 border-white mt-6 ml-9 w-12"></div>
                    <h1 class="text-4xl font-serif text-left ml-9 mt-9 text-white">
                        75 %

                    </h1>
                    <p class="text-white ml-9 mt-6 ">
                        des start-up du secteur jugent les processus de prise de décision des grands groupes trop longs
                    </p>
                    <p class="text-white ml-9 mt-9 mr-24">
                        Source : étude NKCCG
                    </p>
                </div>
            </div>
        </section>
        <section class="bg-gray-200 ">
            <div class="lg:h-12 h-9"></div>

            <div class="lg:mx-24 mx-6 lg:flex">
                <div class="lg:w-1/2 lg:mr-4">
                    <p class="text-black text-xl  ">
                        Les acteurs du secteur de l'ingénierie et de la construction font face à de nouveaux enjeux.
                        NKCCG
                        les accompagne.
                    </p>
                    <ul class="  text-black list-inside mt-9 text-lg ">
                        <li class="flex items-center">
                            <svg class="w-3.5 h-3.5 me-2 text-orange-700 flex-shrink-0" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                <path
                                    d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                            </svg>
                            Une perspective de croissance pour la France ?
                        </li>
                        <li class="flex items-center mt-6">
                            <svg class="w-3.5 h-3.5 me-2 text-orange-700  flex-shrink-0" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                <path
                                    d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                            </svg>
                            Des projets phares

                        </li>
                        <li class="flex items-center mt-6">
                            <svg class="w-3.5 h-3.5 me-2 text-orange-700 flex-shrink-0" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                <path
                                    d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                            </svg>
                            Un secteur en mouvement
                        </li>
                    </ul>
                </div>
                <div class="lg:w-1/2 mt-4 lg:mt-0">
                    <img src="images/damil-gettyimages-835584644-6702024.avif" class="">
                </div>
            </div>
            <div class="h-6"></div>


        </section>
        <section class=" ">
            <!-- Bg Shape -->
            <div class="mx-6 lg:mx-24">
                <div class="lg:h-24 h-9"></div>
                <h1 class="lg:text-4xl text-2xl font-serif text-left  text-black">
                    Ingénierie et construction : des chantiers porteurs
                </h1>
                <h1 class="text-2xl font-bold text-left mt-4 lg:w-2/4 text-black">
                    Une perspective de croissance pour la France ?
                </h1>

                <p class="text-black  mt-6 lg:w-2/4 text-lg">
                    Le secteur de l’ingénierie et de la construction participe à la bonne santé de l’économie française.
                    Les experts de NKCCG estiment qu’1 milliard d’euros investi dans le secteur générerait 2,3 milliards
                    d’euros de revenus additionnels pour l’économie française*.
                </p>
                <h1 class="text-2xl font-bold text-left mt-4 lg:w-2/4 text-black">
                    Des projets phares
                </h1>
                <p class="text-black  mt-4 lg:w-2/4 text-lg">
                    Le secteur reste dépendant de la gestion des budgets d’investissement de l’Etat et des collectivités
                    locales. En France, malgré l’augmentation de la dette publique, l’Etat maintient une politique de
                    grands travaux. Après les récents chantiers LGV (Ligne à Grande Vitesse), l’émergence de grands
                    projets devrait permettre de relancer la croissance et de générer des emplois, mais exposent en
                    contrepartie le secteur à une raréfaction de la main d’œuvre notamment qualifiée.
                </p>
                <p class="text-black  mt-4 lg:w-2/4 text-lg">
                    Cinq grands projets ont démarré en France : EDF Grand carénage, le Grand Paris, le projet Cigéo, le
                    Canal de Seine Nord et les Jeux Olympiques de 2024. Ces projets pourraient permettre de créer plus
                    de 84 000 emplois par an sur la quinzaine d’années à venir. Par exemple, l'accueil des Jeux
                    Olympiques d’été en 2024 à Paris engendrera un investissement de 3 milliards d’euros sur 7 ans et
                    plus de 5 000 emplois potentiels par an.
                </p>
                <h1 class="text-2xl font-bold text-left mt-4 lg:w-2/4 text-black">
                    Un secteur en mouvement
                </h1>
                <p class="text-black  mt-4 lg:w-2/4 text-lg">
                    Plus fondamentalement, l’évolution démographique et l’urbanisation rapide participent activement à
                    la progression de l’activité. En matière de logements 28 « zones tendues » ont été définies dans
                    lesquelles l’offre est insuffisante par rapport à la demande. Autant de zones où le besoin en
                    constructions neuves est fort.
                </p>
                <p class="text-black  mt-4 lg:w-2/4 text-lg">
                    Autres facteurs favorables à l’activité du secteur : le plan de rénovation énergétique et les
                    nouvelles technologies. Rénover le parc immobilier ancien devrait porter également le secteur et
                    créer des opportunités pour les acteurs du marché. Tout comme la domotique et les nouvelles
                    technologies qui accélèrent les procédés de construction (impression 3D) ou améliorent la
                    performance du suivi de chantier (applications, modélisation des données du bâtiment…).
                </p>

                <div class="lg:h-24 h-6"></div>
            </div>
        </section>
        <section class="bg-gray-200 ">
            <div class="lg:h-9"></div>
            <div class="  shadow-solid-13  ">
                <h2 class="fk vj zp   pr text-xl kk wm qb mx-6 lg:mx-24 ">Pour aller plus loin
                </h2>
                <div class="w-full ">

                    <div class="lg:flex lg:mx-24 mx-6  justify-between ">
                        <div class=" ">
                            <img src="images/cq5.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">

                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                15/02/22
                            </p>
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                [Outil] FEC 4.0
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/abhj.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">

                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                15/02/22
                            </p>
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                [Outil] FEC 4.0
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/cq5da.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                15/02/22
                            </p>
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                [Outil] FEC 4.0
                            </p>

                        </div>
                        <div class="">
                            <div class="flex ">
                                <img src="images/tnbyfvc.webp" alt="marketing-digital-service-création-de-site-web"
                                    class=" h-44 w-80 ">
                            </div>

                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                15/02/22
                            </p>
                            <p class=" text-sm  lg:text-lg   mt-4 text-gray-600">
                                [Outil] FEC 4.0
                            </p>


                        </div>
                    </div>
                    <a href="/#"
                        class="flex gi lg:mt-4 w-32  mr-auto ml-auto  text-white bg-orange-600 hover:bg-blue-700 block">
                        <span class="ml-9">Voir plus</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mt-1">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>
                <div class="h-6"></div>
            </div>

        </section>
        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>
        <section class=" lg:h-64 ">
            <div class="h-16 bg-yellow-600">
                <h1 class="text-3xl font-serif text-black mx-16">
                    Contactez-nous
                </h1>

            </div>
            <div class="flex items-center">
                <div class="flex lg:mx-16 mt-6">
                    <div class="flex ">
                        <img src="images/fr-france-800xage.jpg" alt="marketing-digital-service-création-de-site-web"
                            class=" ">
                    </div>
                    <div class=" ">
                        <h1 class="text-2xl mx-6 font-serif text-black">Rami Feghali</h1>
                        <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                            Associé Risques et réglementations FS,<br> NKCCG Bénin et Maghreb
                        </p>
                        <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                    </div>

                </div>

            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>

                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>


                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires

                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact

                            </a>
                        </li>

                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>

        </div>
        </div>

    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/ingenerie.blade.php ENDPATH**/ ?>