<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->


    <!-- ===== Header End ===== -->

    <main>

        <section class=" bg-[url('/images/blog-recent-4.jpg')]  lg:bg-cover mt-16" w-800>
            <div class="bg-white">

                <p class="text-sm mx-5 text-black"><strong>NKCCG </strong> >
                    <strong>Nos expertises </strong> > <strong>Conseil en gestion des risques</strong>
                </p>
            </div>
            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class="  lg:ml-0 mt-32 lg:mt-72 lg:mr-6 lg:px-2 lg:h-64 bg-gray-800">
                    <h1 class="lg:text-4xl text-2xl font-serif text-left lg:ml-9 lg:mr-14 mt-28 text-white inline-block  px-4">
                        Conseil en gestion des risques
                    </h1>
                    <h1 class="text-xl font-serif lg:text-left lg:ml-9  text-white  lg:mr-64 px-4">
                        Pour un management des risques performant et « résilient »
                    </h1>
                    <div class="lg:ml-9 px-4 lg:px-0 mt-4">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>



                </div>

            </div>

        </section>
        <section class="">

            <div class=" py-10 ">




                <div class="grid gap-6 mb-6 md:grid-cols-4 lg:mx-12  ">
                    <div class=" mt-5 ">
                        <p class="font-bold text-gray-500 mb-2 lg:mx-0 mx-6">A la une</p>
                        <img src="images/2.webp" alt="" class="mb-2 lg:mx-0 mx-6">

                    </div> </div>
                    <div class="">

                        <img src="images/3.webp" alt="" class="lg:mt-12 mt-6 lg:mx-0 mx-6">



                    </div>
                    <div class="">


                        <img src="images/7.webp" alt="" class="lg:mt-12 mt-6 lg:mx-0 mx-6">


                    </div>
                    <div class="">
                        <img src="images/8.webp" alt="" class="lg:mt-12 mt-6 lg:mx-0 mx-6">




                    </div>




                </div>


            </div>


        </section>
        <section class="lg:w-1/2 lg:mx-8 mx-6">
            <p class=" text-gray-800 py-5 text-xl"> L’environnement dans lequel vous évoluez est en constant
                changement, toujours plus complexe, plus connecté. Les entreprises sont confrontées à de nouveaux
                risques, parfois encore mal connus. Mais ces risques vont toujours de pair avec de nouvelles
                opportunités</p>

            <p class=" text-gray-800 py-5 text-xl">Les fonctions de gestion des risques sont au premier rang de ces
                changements, prêtes à transformer la façon dont vous percevez et capitalisez sur ces risques. </p>


        </section>
        <section class="">

            <div class=" bg-gray-200 py-10 lg:px-5 ">


                <h2 class="lg:w-1/2 py-5 lg:text-4xl text-2xl text-gray-800 lg:mx-5 mx-6 mb-10 ">Professionnels du risque : comment accélérer
                    vos enjeux business grâce à la technologie ?</h2>

                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mx-12 mx-6 ">
                    <div class="lg:mr-6  ">

                        <div class="">
                            <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl ">Retour en vidéo sur
                                le NKCCG Risk Day,
                                une demi journée immersive qui a réuni de nombreux professionnels du risque autour des
                                tendances
                                et défis liés à la digitalisation. Un moment propice aux échanges avec des retours
                                d’expérience
                                et des pistes d'action concrètes pour faire de la technologie un véritable levier de
                                performance.
                                Découvrez les témoignages des participants.</p>
                        </div>

                        <div class="flex justify-center items-center mt-10">
                            <button type="button"
                                class="py-2.5 px-5 me-2 mb-2  text-lg font-medium text-white text-center focus:outline-none bg-orange-600 border border-gray-200 hover:bg-white hover:text-gray-900 focus:z-10 focus:ring-4 focus:ring-gray-200 ">Voir
                                plus sur nos solutions: NKCCG store</button>

                        </div>


                    </div>
                    <div class="">


                        <h3 class="font-bold text-2xl text-gray-800 ml-10 mb-1 ">Video</h3>
                        <p class="ml-10 mb-5">Veuillez accepter tous les cookies pour visionner cette vidéo.</p>

                        <div class="flex justify-center items-center">
                            <button type="button"
                                class=" py-2.5 px-5 me-2 mb-2  text-lg font-bold text-gray-900 text-center focus:outline-none bg-transparent border border-gray-400 hover:bg-gray-500 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-200 ">Paramètres
                                des cookies</button>
                        </div>



                    </div>




                </div>


            </div>

        </section>
        <section class="">

            <div class=" py-10 ">




                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mx-12 mx-6">
                    <div class="lg:mr-6 ">
                        <h2 class="lg:text-4xl text-2xl text-gray-800 lg:mx-5 mb-5 ">Notre accompagnement</h2>

                        <div class=" mt-9">

                            <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-5 text-lg">NKCCG vous aide à
                                identifier vos enjeux liés à la gestion des risques plus tôt et plus rapidement, pas
                                seulement pour adresser vos risques actuels, mais également pour anticiper vos
                                challenges futurs.</p>
                            <P class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-5 text-lg ">Nous analysons
                                vos processus, procédures, systèmes d’informations ou vos dispositifs de contrôle avec
                                une nouvelle perspective, pour vous accompagner dans une approche de la gestion des
                                risques holistique vous permettant de prendre les meilleures décisions.</P>
                            <P class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-5 text-lg ">Conseil en risk
                                management : nous sommes prêts à vous aider dans la transformation de votre activité,
                                pour faire de vos risques de nouvelles opportunités. Découvrez comment... </P>
                        </div>
                    </div>
                    <div class="">
                        <div class="lg:mx-8 my-8">
                            <img class=" mb-5 " alt="" w- style="background-color: transparent;"
                                src="/images/African_workplace.png">
                        </div>




                    </div>




                </div>


            </div>

        </section>
        <section class="  bg-gray-100 py-5">

            <div class=" ">

                <p class="text-xl font-bold text-gray-400 leading-relaxed mx-6 tracking-wide lg:mx-8 mb-5 mt-4 lg:mt-8">Nos expertises
                </p>


                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mr-8 mx-6 lg:mx-0 lg:ml-8">
                    <div class=" lg:mt-5 ">

                        <button
                            class="flex items-center justify-between bg-transparent lg:h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl">Audit média et optimisation des investissements
                                publicitaires</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Ethique et conformité</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">gestion des risques liées aux tiers </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl">Gestion des risque et contrôle interne</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>


                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Services a l' audit interne</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>





                    </div>
                    <div class="">
                        <div class=" lg:mt-5">

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Delai de paiement</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Gestion de crise</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Litiges et investigations </span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent lg:h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Maitrise des risque technologiques</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>





                        </div>



                    </div>




                </div>


            </div>

        </section>
        <section class="">

            <div class="py-10 ">




                <div class="grid gap-6 mb-6 md:grid-cols-4 lg:mx-12 mx-6">
                    <div class=" mt-5 ">
                        <p class="font-bold text-gray-500 mb-2">Gestion des risques : toute l'actualité</p>
                        <img src="images/cq5dam.thumbnail.319.319 (2).webp" alt="" class="mb-2">
                        <p class="text-sm text-gray-800 font-bold mb-2">15/01/24</p>
                        <p class="text-xl text-gray-800"> Prospérer à l’ère de la réinvention continue, 27e CEO Survey
                        </p>

                    </div </div>
                    <div class="">

                        <img src="images/cq5dam.thumbnail.319.319.webp" alt="" class="mt-12">
                        <p class="text-sm text-gray-800 font-bold mt-2"> 07/11/23</p>
                        <p class="text-xl text-gray-800">Et si la sécurité était au cœur de l'innovation ?</p>



                    </div>
                    <div class="">


                        <img src="images/3.webp" alt="" class="mt-12">
                        <p class="text-sm text-gray-800 font-bold mt-2">25/05/23</p>
                        <p class="text-xl text-gray-800">Global Crisis and Resilience Survey 2023</p>


                    </div>
                    <div class="">
                        <img src="images/4.webp" alt="" class="mt-12">
                        <p class="text-sm text-gray-800 font-bold mt-2">07/03/23</p>
                        <p class="text-xl text-gray-800">
                            Règlement DORA : comment s’y préparer ?</p>



                    </div>




                </div>
                <div class="grid gap-6 mb-6 md:grid-cols-4 lg:mx-12 mx-6">
                    <div class=" mt-10 ">
                        <p class="font-bold text-gray-500 mb-2"></p>
                        <img src="images/5.webp" alt="" class="mb-2">
                        <p class="text-sm text-gray-800 font-bold mb-2">28/11/22</p>
                        <p class="text-xl text-gray-800">
                            Reporting RSE : les nouvelles obligations de contrôle interne</p>

                    </div </div>
                    <div class="">

                        <img src="images/6.webp" alt="" class="mt-12">
                        <p class="text-sm text-gray-800 font-bold mt-2"> 01/08/22</p>
                        <p class="text-xl text-gray-800">
                            Risk managers en temps de transition</p>



                    </div>
                    <div class="">


                        <img src="images/7.webp" alt="" class="mt-12">
                        <p class="text-sm text-gray-800 font-bold mt-2">13/12/21</p>
                        <p class="text-xl text-gray-800">
                            Baromètre du Compliance Officer 2021</p>


                    </div>
                    <div class="">
                        <img src="images/8.webp" alt="" class="mt-12">
                        <p class="text-sm text-gray-800 font-bold mt-2"> 21/05/21</p>
                        <p class="text-xl text-gray-800">

                            Quels sont les challenges des fonctions de gestion des risques autour des enjeux RSE ?</p>



                    </div>




                </div>

                <div class="flex justify-center items-center">
                    <button type="button"
                        class="py-2.5 px-5 me-2 mb-2  text-lg font-medium text-gray-900 text-center focus:outline-none bg-white border border-gray-200 hover:bg-orange-700 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-200 ">Voir
                        plus</button>
                </div>
            </div>


        </section>
        <section class="bg-orange-600">
            <!-- Bg Shape -->
            <div class="flex   lg:h-44 lg:mx-64 mx-6 ">
                <img src="images/icon_phone.webp" class="h-24 mt-6">

                <div class="">

                    <p class="text-white lg:ml-4 mt-6 ">
                        Retrouvez toutes nos actualités
                    </p>
                    <a href="/contact" class="flex  gi lg:mt-1 lg:ml-4  text-white lg:text-3xl  text-lg block">
                        <span class=" font-bold"> Abonnez-vous à la newsletter Gestion des Risques !</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h-9 mt-">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>

            </div>
        </section>
        <section class="">

            <div class=" bg-gray-100 lg:py-10 ">




                <div class="grid gap-6 mb-6 md:grid-cols-3 lg:mx-12 mx-6">
                    <div class=" mt-5 ">
                        <p class="font-bold text-gray-500 mb-2 text-xl">Pour aller plus loin</p>
                        <img src="images/2.webp" alt="" class="mb-2">


                        <p class="text-xl text-gray-800">Gestion des risques financiers : anticiper<br> et gérer les
                            enjeux</p>
                    </div </div>



                </div>

            </div>


        </section>

        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>

                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>


                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires

                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact

                            </a>
                        </li>

                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>

        </div>
        </div>

    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/gestion.blade.php ENDPATH**/ ?>