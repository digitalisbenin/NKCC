<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->

   

    <!-- ===== Header End ===== -->

    <main>

        <section class=" bg-[url('/images/blog-recent-5.jpg')]  lg:bg-cover mt-16" w-800>
            <div class="bg-white">
                <p class="text-sm mx-5 text-black"><strong>NKCCG </strong> >
                    <strong> Nos expertises > </strong> <strong> Conseil aux organisations</strong>
                </p>
            </div>
            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class=" mt-72   lg:px-20 h-64 bg-gray-800">
                    <h1 class="text-4xl font-serif text-left ml-6 mr-14 mt-20 text-white  px-4">
                        Conseil aux organisations
                    </h1>

                    <div class="ml-9  mt-4">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>



                </div>

            </div>

        </section>
        <section class="">

            <div class=" mx-6 ">

                <p class="text-xl font-bold text-gray-400 leading-relaxed  tracking-wide lg:mx-8  mb-5 mt-8">Améliorez
                    votre performance, maîtrisez vos risques, réussissez vos transformations</p>


                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mr-8  lg:ml-8">
                    <div class=" mt-5 ">

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Achats</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Costomer Transformation</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Data Intelligence </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Développement international et coopération</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>


                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Finances</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Opérations</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Startups, grands groupes et pouvoirs publics</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Technologie</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>



                    </div>
                    <div class="">
                        <div class=" lg:mt-5">

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl">Croissance des entreprises familiales</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl">Cybersécurité</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Développement durable </span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Expérience client</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>


                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Gestion du capital humain</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Portfolio & Program Management (PPM)</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Strategy&:conseil en strategie</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl">Transformation digitale</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>



                        </div>



                    </div>




                </div>


            </div>

        </section>

        <section class="bg-orange-600">
            <!-- Bg Shape -->
            <div class="flex   lg:h-44 lg:mx-64 mx-6">
                <img src="images/go-there-white.webp" class="h-24 mt-6 mr-10">

                <div class="">

                    <p class="text-white lg:ml-4 mt-6 ">
                        Analyst Relations program
                    </p>
                    <a href="/contact" class="flex  gi lg:mt-1 lg:ml-4  text-white lg:text-3xl text-xl  block">
                        <span class=" font-bold">
                            Développer des relations avec les acteurs leaders de la technologie à travers le monde
                        </span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h-9 mt-">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                        </svg>
                    </a>
                </div>

            </div>
        </section>
        <section class="">

            <div class=" bg-gray-100 dark:bg-blacksection dark:border-strokedark ">



                <div class="border-t-2 border-orange-500  h-[1rem] mt-5 mx-10"></div>
                <div class="grid gap-6 mb-6 md:grid-cols-4 lg:mx-12 mx-6">

                    <div class=" mt-5 ">
                        <p class="font-bold text-gray-500 mb-2"> Nos clients témoignent</p>
                        <img src="images/3.webp" alt="" class="mb-2">

                        <p class="text-xl text-gray-800"> Externaliser son audit interne : le choix stratégique de
                            Powens</p>

                    </div </div>
                    <div class="">

                        <img src="images/4.webp" alt="" class="mt-12 mb-3">

                        <p class="text-xl text-gray-800">Formation à la CSRD : l'engagement de Michelin et l'expertise
                            NKCCG portent leurs fruits</p>


                    </div>
                    <div class="">


                        <img src="images/5.webp" alt="" class="mt-12 mb-3">


                        <p class="text-xl text-gray-800">Un nouveau modèle économique pour le sport français : le CNOSF
                            aide les fédérations à sortir plus fortes de la pandémie​</p>

                    </div>
                    <div class="">
                        <img src="images/6.webp" alt="" class="mt-12 mb-3">


                        <p class="text-xl text-gray-800">Un reporting achats agile, outil de pilotage et de
                            communication pour Paris 2024</p>



                    </div>




                </div>

                <div class="flex justify-center items-center">
                    <button type="button"
                        class="py-2.5 px-5 me-2 mb-2  text-lg font-medium text-gray-900 text-center focus:outline-none bg-transparent border border-gray-800 hover:bg-orange-700 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-200 ">Voir
                        plus</button>
                </div>
            </div>


        </section>
        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>
        <section class=" lg:h-64 ">
            <div class="h-16 bg-yellow-600">
                <h1 class="text-3xl font-serif text-black mx-16">
                    Contactez-nous
                </h1>

            </div>
            <div class="flex items-center">
                <div class="flex lg:mx-16 mt-6">
                    <div class="flex ">
                        <img src="images/fr-france-800xage.jpg" alt="marketing-digital-service-création-de-site-web"
                            class=" ">
                    </div>
                    <div class=" ">
                        <h1 class="text-2xl mx-6 font-serif text-black">Rami Feghali</h1>
                        <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                            Associé Risques et réglementations FS,<br> NKCCG Bénin et Maghreb
                        </p>
                        <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                    </div>

                </div>

            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>

                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>


                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires

                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact

                            </a>
                        </li>

                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>

        </div>
        </div>

    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/organisations.blade.php ENDPATH**/ ?>