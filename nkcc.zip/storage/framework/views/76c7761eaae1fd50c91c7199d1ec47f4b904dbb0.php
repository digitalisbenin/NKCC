<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NKCCG</title>
    <link rel="icon" href="favicon.ico">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body x-data="{ page: 'home', 'darkMode': true, 'stickyMenu': false, 'navigationOpen': false, 'scrollTop': false }" x-init="darkMode = JSON.parse(localStorage.getItem('darkMode'));
$watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{ 'b eh': darkMode === true }">
    <!-- ===== Header Start ===== -->

    <!-- ===== Header End ===== -->

    <main>

        <section class=" bg-[url('/images/blog-1.jpg')]  lg:bg-cover mt-16" w-800>
            <div class="bg-white">
                <p class="text-sm mx-5 text-black"><strong>NKCCG > </strong>
                    <strong>
                        Et vous, quelle équation voulez-vous résoudre ? >
                    </strong> <strong>Performance et responsabilité sociale de l’entreprise </strong>
                </p>
            </div>


            <!-- Bg Shape -->
            <div class="tc  w-full   ">

                <div class="  lg:ml-6 mt-44 lg:mt-72 lg:mr-6 lg:px-20 lg:w-2/3">
                    <h1
                        class="lg:text-4xl text-2xl font-serif text-left ml-9 mr-14 mt-32 text-white inline-block bg-gray-800 px-4">
                        Culture et responsabilité d'entreprise
                    </h1>
                    <h1 class="text-xl font-serif text-left ml-9  text-white bg-gray-800 mr-32 px-4">
                        Concilier performance et responsabilité sociale de l’entreprise
                    </h1>
                    <div class="ml-9  mt-2 mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="w-9 h- text-white bg-black">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>

                    </div>



                </div>

            </div>
            <div class="w-full bg-red-600 text-white px-auto mx-auto">
                <div class="grid gap-6 mb-6 md:grid-cols-3 mx-auto">
                    <div class="inline-block mt-5 ml-8">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">2/3</h1>
                        <p class="my-2 text-xl">des millennials aspirent à travailler pour une entreprise à impact
                            positif

                        </p>
                        <p class="text-sm my-5">Source : Institut Global Tolerance, The Value Resolution</p>

                    </div>

                    <div class="inline-block mt-5 lg:mx-4 ml-8 lg:ml-0">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem]"></div>
                        <h1 class="text-4xl">67 %</h1>
                        <p class="my-2 text-xl">des entreprises ont engagé des projets de transformation des
                            compétences

                        </p>

                        <p class="text-sm my-5">Source : Transition des compétences dans un monde digital</p>
                    </div>

                    <div class="inline-block mt-5 lg:mx-4 ml-8 lg:ml-0">
                        <div class="border-t-2 border-white w-[3.5rem] h-[1rem] "></div>
                        <h1 class="text-4xl">61 %</h1>
                        <p class="my-2 text-xl">des dirigeants français s’organisent pour une économie plus verte

                        </p>

                        <p class="text-sm my-5">Source : Etude NKCCG - Global CEO Survey 2021</p>
                    </div>



                </div>
            </div>
        </section>
        <section class="lg:w-1/2 lg:mx-8 mx-6">




            <div>

                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">Parce que les entreprises
                    apparaissent désormais comme une solution de premier plan face à la fragilité de certains modèles
                    économiques, les questions de culture et de responsabilité d’entreprise font partie des
                    transformations incontournables à mener.</p>
                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">L'enjeu est de réconcilier
                    business et sens de l’action, ce qui implique de redéfinir la notion de performance. Les entreprises
                    s’affirment aujourd’hui comme des acteurs contribuant plus largement à l’intérêt général, et la
                    question de leur acceptabilité sociale devient un vrai sujet.</p>
                <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 text-xl mb-5">L’avenir des organisations ne
                    repose plus uniquement sur leur performance économique. Une refonte de leurs systèmes de valeurs et
                    modes de fonctionnement leur permettra d'atteindre cette nouvelle performance.</p>

            </div>



        </section>
        <section class=" lg:py-10">

            <div class=" bg-gray-100 dark:bg-blacksection dark:border-strokedark  lg:py-10">


                <h2 class="lg:text-4xl text-2xl text-gray-800 lg:mx-8 mx-6 py-1 lg:px-10 mb-5  ">Assurer sa transformation en conciliant
                    business et <br> sens de l’action</h2>



                <div class="mx-6 lg:mx-12 mt-5 lg:flex ">
                    <div class="lg:mr-6 mt-5 lg:w-1/3 ">
                        <button
                            class= "mb-2 flex items-center justify-between bg-red-700 h-16  lg:ml-10 px-4 border border-gray-400 mb-2">
                            <span class=" text-xl text-white">Intégrer les aspects RSE dans sa stratégie</span>

                        </button>
                        <p class="text-center text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">L’humain doit
                            occuper une place centrale</p>



                        </p>


                    </div>
                    <div class=" lg:w-2/3">
                        <div class=" mt-5">
                            <h3 class="lg:text-4xl text-2xl font-bold text-gray-800 mb-5 lg:mx-7">Intégrer les aspects RSE dans sa
                                stratégie</h3>
                            <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">Face aux fractures
                                sociétales et à l’impact des grandes évolutions environnementales, l’entreprise, par ses
                                actions, devient acteur et moteur de la transformation sociétale et environnementale –
                                deux dimensions que la société demande de plus en plus aux organisations de prendre en
                                considération dans leur stratégie. </p>
                            <p class="text-gray-800 leading-relaxed  tracking-wide lg:mx-8 mb-4">L’entreprise compétitive
                                de demain sera celle qui saura exprimer le sens de son activité en définissant sa
                                performance économique en lien avec son impact social, sociétal et environnemental. </p>



                        </div>



                    </div>




                </div>


            </div>

        </section>
        <section class="">

            <div class=" ">

                <h1 class="lg:text-4xl text-2xl text-gray-800 mx-5 lg:mb-5 lg:ml-20 leading-relaxed  tracking-wide">Anticiper et faire
                    évoluer son activité pour <br> gagner en confiance et stabiliser sa <br> performance</h1>


                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mx-12 mx-6 ">
                    <div class="lg:mr-6 mt-5 ">


                        <div class=" lg:mt-15">

                            <P class="text-gray-800 mb-5 leading-relaxed  tracking-wide lg:mx-8 text-xl">Changer fait
                                partie de la vie d’une entreprise : se réorganiser face aux épreuves à surmonter, mettre
                                en œuvre les actions nécessaires pour rebondir, s’adapter pour saisir une opportunité,
                                renforcer sa compétitivité grâce à l'innovation, anticiper les virages en décelant les
                                premiers signaux dans les marchés ou auprès des clients… </P>
                        </div>



                        <div class=" lg:mt-15">

                            <P class="text-gray-800 mb-5 leading-relaxed  tracking-wide lg:mx-8 text-xl">C’est donc vers
                                une refonte de ses systèmes de valeurs et du fonctionnement des organisations que va
                                l’entreprise, tout en cherchant à se questionner sur son rôle et sa contribution au
                                monde.</P>
                        </div>
                        <div class=" lg:mt-15">

                            <P class="text-gray-800 mb-5 leading-relaxed  tracking-wide lg:mx-8 text-xl">Pour maximiser la
                                confiance au sein de leur écosystème et leurs parties prenantes, les entreprises doivent
                                aujourd’hui anticiper les impacts digitaux, technologiques, sociétaux et business sur
                                les compétences et ressources. Elles doivent s’engager dans une démarche d’upskilling et
                                de reskilling de leurs équipes.</P>
                        </div>


                    </div>
                    <div class="">
                        <div class="lg:mx-8 my-8">
                            <img class=" mb-5 " alt="" w- style="background-color: transparent;"
                                src="/images/African_workplace.png">
                        </div>




                    </div>




                </div>


            </div>

        </section>
        <section class="bg-gray-200 ">
            <div class="h-9"></div>
            <div class="  shadow-solid-13  ">
                <h2 class="fk vj zp   pr text-xl kk wm qb  mx-6 lg:mx-24 text-gray-500 ">Pour aller plus loin
                </h2>
                <div class="w-full ">

                    <div class="lg:flex mx-6 lg:mx-12  justify-between ">
                        <div class=" ">
                            <img src="images/cq5dam.thumbnail.319.319.webp"
                                alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">


                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Prospérer à l’ère de la réinvention <br> continue, 27e CEO Survey
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/cq5dam.thumbnai.webp"
                                alt="marketing-digital-service-création-de-site-web" class="h-44 w-80">


                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                Gouvernance et performance
                            </p>

                        </div>
                        <div class=" ">
                            <img src="images/cq5da.webp" alt="marketing-digital-service-création-de-site-web"
                                class="h-44 w-80">

                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                M&A : checklist des signaux ESG<br> qui invitent à la prudence <br>lors d’une
                                transaction
                            </p>

                        </div>
                        <div class="">
                            <div class="flex ">
                                <img src="images/cq5dam.tl.319.319.webp"
                                    alt="marketing-digital-service-création-de-site-web" class=" h-44 w-80 ">
                            </div>

                            <p class=" text-sm  lg:text-xl   mt-4 text-gray-600">
                                L’humain au centre de <br> l’échiquier
                            </p>


                        </div>
                    </div>
                    <a href="/#"
                        class="lg:flex gi lg:mt-4 w-32  mr-auto ml-auto border border-gray-800 text-gray-800 bg-transparent hover:bg-orange-600 hover:text-white block">
                        <span class="ml-9">Voir plus</span>
                        
                    </a>
                </div>
                <div class="h-6"></div>
            </div>

        </section>

        <section class=" py-5">

            <div class=" ">

                <p class="text-xl font-bold text-gray-400 leading-relaxed  tracking-wide mx-6 lg:mx-8 mb-5 mt-8">Quelles autres
                    équations voulez-vous résoudre ?</p>


                <div class="grid gap-6 mb-6 md:grid-cols-2 lg:mr-8 mx-6 lg:mx-0 lg:ml-8">
                    <div class=" lg:mt-5 ">

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Transition écologique et sociétale</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>



                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Culture et responsabilité d'entreprise</span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Création et préservation de valeur </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>

                        <button
                            class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                            <span class="font-bold text-xl ">Croissance des entreprises familiales/ETI </span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                            </svg>
                        </button>



















                    </div>
                    <div class="">
                        <div class=" lg:mt-5">

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Technologie et performance</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl ">Transparence et maîtrise des risques</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl">Transformation des business models</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>

                            <button
                                class="flex items-center justify-between bg-transparent h-12 text-black hover:bg-red-600 hover:text-white w-full px-4 border border-gray-400 mb-2">
                                <span class="font-bold text-xl"> Startups et innovation </span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6 mt-">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </button>






                        </div>



                    </div>




                </div>


            </div>

        </section>


        <section class="mt-2 bg-black  flex items-center justify-center">
            <div class="h-16 flex">
                <h1 class="lg:text-3xl text-xl font-serif text-white mt-4">
                    Suivez-nous !
                </h1>
                <img src="images/follow_linkedin.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-6 mt-4">
                <img src="images/follow_twitter.png" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_youtube.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
                <img src="images/follow_instagram.webp" class="lg:h-9 lg:w-9 w-6 h-6 ml-2 mt-4">
            </div>
        </section>
        <section class=" lg:h-64 ">
            <div class="h-16 bg-yellow-600">
                <h1 class="text-3xl font-serif text-black mx-16">
                    Contactez-nous
                </h1>

            </div>
            <div class="flex items-center">
                <div class="flex lg:mx-16 mt-6">
                    <div class="flex ">
                        <img src="images/fr-france-800xage.jpg" alt="marketing-digital-service-création-de-site-web"
                            class=" ">
                    </div>
                    <div class=" ">
                        <h1 class="text-2xl mx-6 font-serif text-black">Rami Feghali</h1>
                        <p class="mx-6 text-sm  lg:text-sm  mt-2 text-gray-600">
                            Associé Risques et réglementations FS,<br> NKCCG Bénin et Maghreb
                        </p>
                        <h1 class="text-xl mx-6 font-bold text-black">Email</h1>
                    </div>

                </div>

            </div>
        </section>


    </main>
    <!-- ===== Footer Start ===== -->
    <footer class=" bg-gray-700 lg:h-96">

        <!-- Footer Top -->
        <h1 class="text-xl ml-16 text-white ">
            NKC CONSULTING GROUP
        </h1>
        <div class="bb ze ki xn 2xl:ud-px-0 mt-6">
                <nav>
                    <ul class="tc _o sf yo cg ep">
                        <li><a href="/"
                                class=" text-white xl hover:text-orange-500  <?php echo e(request()->is('/') ? 'text-blue-700' : ''); ?>  ">
                                Enjeux</a>
                        </li>

                        <li class="c i" x-data="{ dropdown: false }">
                            <a href="/solutions-numeriques"
                                class="tc wf yf bg  xl text-white hover:text-orange-500 <?php echo e(request()->is('solutions-numeriques') ? 'text-blue-700' : ''); ?> ">
                                Secteur d'activité
                            </a>


                            <!-- Dropdown End -->
                        </li>
                        <li><a href="/a-propos"
                                class="  xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">Expertises
                            </a></li>
                        <li><a href="/contact"
                                class="xl  text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Solutions
                                digitales</a>
                        </li>
                        <li><a href="/a-propos"
                                class=" xl text-white hover:text-orange-500 <?php echo e(request()->is('a-propos') ? 'text-blue-700' : ''); ?> ">
                                Qui sommes-nous ?</a></li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Partenaires

                            </a>
                        </li>
                        <li><a href="/contact"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Carrières
                            </a>
                        </li>

                        <li><a href="/#"
                                class="xl text-white hover:text-orange-500 <?php echo e(request()->is('contact') ? 'text-blue-700' : ''); ?>">Contact

                            </a>
                        </li>

                    </ul>
                </nav>            
        </div>
        <div class="   mt-2 bg-white lg:mx-16 border border-line"></div>
        <p class="text-white  mt-6 lg:mx-48  text-sm mx-6">
            © 2012 - 2024 NKCCG. Tous droits réservés "NKCCG" fait référence au
            réseau NKCCG <br>et/ou à une ou plusieurs de ses entités membres, dont chacune constitue une entité
            juridique
            distincte. Pour plus <br> d'information, rendez-vous sur le site www.nkccg.com
        </p>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Alerte à la fraude
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Contactez-nous
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration d’accessibilité
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Déclaration de confidentialité
            </h1>
        </div>
        <div class="lg:flex lg:mx-48 lg:mt-9 mt-4 mx-6">
            <h1 class="text-sm   text-white ">
                Informations légales
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Information sur les cookies
            </h1>
            <h1 class="text-sm   text-white lg:ml-6 ">
                Paramétrer les cookies
            </h1>

        </div>
        </div>

    </footer>
    <!-- Footer Top -->


    <!-- Footer Bottom -->

    <!-- ===== Footer End ===== -->

    <!-- ====== Back To Top Start ===== -->
    <button class="xc wf xf ie ld vg sr gh tr g sa ta _a bg-orange-500 mb-9 mr-6 lg:mr-0 "
        @click="window.scrollTo({top: 0, behavior: 'smooth'})"
        @scroll.window="scrollTop = (window.pageYOffset > 50) ? true : false" :class="{ 'uc': scrollTop }">
        <svg class="uh se qd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
                d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
        </svg>
    </button>


</html>
<!-- ====== Back To Top End ===== -->

<script>
    //  Pricing Table
    const setup = () => {
        return {
            isNavOpen: false,
            showModalModele: false,

            billPlan: 'monthly',

            plans: [{
                    name: 'Starter',
                    price: {
                        monthly: 29,
                        annually: 29 * 12 - 199,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Growth Plan',
                    price: {
                        monthly: 59,
                        annually: 59 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
                {
                    name: 'Business',
                    price: {
                        monthly: 139,
                        annually: 139 * 12 - 100,
                    },
                    features: ['400 GB Storaget', 'Unlimited Photos & Videos', 'Exclusive Support'],
                },
            ],
        };
    };
    toggleModalModele() {
        this.showModalModele = !this.showModalModele;
    },
</script>
<script defer src="js/bundle.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\nkcc\resources\views/culture.blade.php ENDPATH**/ ?>